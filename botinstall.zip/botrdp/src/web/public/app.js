// Panel VPS/RDP — frontend (vanilla JS, no build step).
const $ = (id) => document.getElementById(id);
async function api(path, opts = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
    ...opts,
    body: opts.body ? JSON.stringify(opts.body) : undefined
  });
  const data = await res.json().catch(() => ({ ok: false, message: 'Bad response' }));
  return { status: res.status, ...data };
}

let loginUserId = null;
let pollTimer = null;

// ---- Toast / messages ----
function toast(msg, type = '') {
  const el = $('app-msg');
  el.textContent = msg;
  el.className = 'msg floating show ' + type;
  setTimeout(() => { el.className = 'msg floating ' + type; }, 3000);
}
function loginMsg(msg, type = '') {
  const el = $('login-msg');
  el.textContent = msg;
  el.className = 'msg ' + type;
}

// ---- Auth flow ----
$('btn-request-code').onclick = async () => {
  const identifier = $('identifier').value.trim();
  if (!identifier) return loginMsg('Isi username / user ID dulu.', 'error');
  loginMsg('Mengirim kode...');
  const r = await api('/api/auth/request-code', { method: 'POST', body: { identifier } });
  if (!r.ok) return loginMsg(r.message, 'error');
  loginUserId = r.userId;
  $('step-identifier').classList.add('hidden');
  $('step-code').classList.remove('hidden');
  loginMsg(r.message, 'success');
};

$('btn-back-identifier').onclick = () => {
  $('step-code').classList.add('hidden');
  $('step-identifier').classList.remove('hidden');
  loginMsg('');
};

$('btn-verify-code').onclick = async () => {
  const code = $('code').value.trim();
  if (!code) return loginMsg('Masukkan kode.', 'error');
  loginMsg('Memverifikasi...');
  const r = await api('/api/auth/verify-code', { method: 'POST', body: { userId: loginUserId, code } });
  if (!r.ok) return loginMsg(r.message, 'error');
  await enterApp();
};

$('btn-logout').onclick = async () => {
  await api('/api/auth/logout', { method: 'POST' });
  location.reload();
};

// ---- Enter app ----
async function enterApp() {
  const me = await api('/api/me');
  if (!me.ok) { showLogin(); return; }
  $('login-view').classList.remove('active');
  $('app-view').classList.add('active');
  const uname = me.username ? '@' + String(me.username).replace(/^@/, '') : ('ID ' + me.userId);
  $('user-badge').textContent = (me.isAdmin ? '👑 Admin • ' : '🧑 Renter • ') + uname;
  await Promise.all([loadServers(), loadApis()]);
}
function showLogin() {
  $('app-view').classList.remove('active');
  $('login-view').classList.add('active');
}

// ---- Tabs ----
document.querySelectorAll('.tab').forEach(tab => {
  tab.onclick = () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    $('tab-' + tab.dataset.tab).classList.add('active');
    if (tab.dataset.tab === 'power') loadPowerApis();
    if (tab.dataset.tab === 'install') loadInstallApis();
  };
});

// ---- Servers ----
function serverItem(x, actionsHtml) {
  const type = x.type === 'rdp' ? 'RDP' : 'VPS';
  const server = x.type === 'rdp' && x.ip ? `${x.ip}:${x.rdp_port}` : (x.ip || '-');
  return `<div class="item">
    <div class="item-info">
      <div class="item-title"><span class="badge ${x.type}">${type}</span> ${server}</div>
      <div class="item-sub">API#${x.api_id ?? '-'} • ${x.size_slug || '-'} • ${x.region || '-'}</div>
    </div>
    <div class="item-actions">${actionsHtml || ''}</div>
  </div>`;
}

async function loadServers() {
  const r = await api('/api/instances');
  const box = $('servers-list');
  if (!r.ok || !r.instances.length) { box.innerHTML = '<div class="empty">Belum ada VPS/RDP.</div>'; return; }
  box.innerHTML = r.instances.map(x => serverItem(x)).join('');
}

// ---- Power (API-first + cek status cloud) ----
async function loadPowerApis() {
  const r = await api('/api/apis');
  const sel = $('power-api-select');
  if (!r.ok || !r.apis.length) {
    sel.innerHTML = '<option value="">Belum ada API</option>';
    $('power-list').innerHTML = '<div class="empty">Tambahkan API dulu di tab API Cloud.</div>';
    return;
  }
  sel.innerHTML = r.apis.map(a => `<option value="${a.id}">${a.provider || 'DigitalOcean'} API#${a.id} • ${a.email || '-'}</option>`).join('');
  sel.onchange = () => loadPowerInstances(sel.value);
  loadPowerInstances(sel.value);
}

async function loadPowerInstances(apiId) {
  if (!apiId) return;
  const statusEl = $('power-status');
  statusEl.textContent = 'Cek status akun cloud...';
  statusEl.className = 'status-line';
  const st = await api(`/api/apis/${apiId}/status`);
  if (st.ok && st.status.ok) {
    statusEl.textContent = `Status akun cloud: 🟢 ${st.status.label} (${st.status.email})`;
    statusEl.className = 'status-line ok';
  } else {
    const reason = st.ok ? st.status.reason : st.message;
    statusEl.textContent = `Status akun cloud: ⚠️ Bermasalah — ${reason}`;
    statusEl.className = 'status-line bad';
  }

  const r = await api('/api/instances?apiId=' + encodeURIComponent(apiId));
  const box = $('power-list');
  if (!r.ok || !r.instances.length) { box.innerHTML = '<div class="empty">Tidak ada server untuk API ini.</div>'; return; }
  box.innerHTML = r.instances.map(x => serverItem(x,
    `<button class="btn on small" onclick="powerAction(${x.id},'on')">ON</button>
     <button class="btn off small" onclick="powerAction(${x.id},'off')">OFF</button>`
  )).join('');
}

window.powerAction = async (id, action) => {
  toast('Mengirim ' + action.toUpperCase() + '...');
  const r = await api(`/api/instances/${id}/power`, { method: 'POST', body: { action } });
  toast(r.ok ? `✅ ${action.toUpperCase()} terkirim` : ('❌ ' + r.message), r.ok ? 'success' : 'error');
};

// ---- API Cloud ----
async function loadApis() {
  const r = await api('/api/apis');
  const box = $('apis-list');
  if (!r.ok || !r.apis.length) { box.innerHTML = '<div class="empty">Belum ada API cloud.</div>'; return; }
  box.innerHTML = r.apis.map(a => `<div class="item">
    <div class="item-info">
      <div class="item-title">${a.provider || 'DigitalOcean'} API#${a.id}</div>
      <div class="item-sub">${a.email || '-'} • ${Number(a.status) === 1 ? 'Aktif' : 'Nonaktif'}</div>
    </div>
    <div class="item-actions">
      <button class="btn danger small" onclick="deleteApi(${a.id})">Hapus</button>
    </div>
  </div>`).join('');
}

$('btn-add-api').onclick = async () => {
  const token = $('add-api-token').value.trim();
  const provider = $('add-api-provider').value;
  if (!token) return toast('Isi token dulu.', 'error');
  const r = await api('/api/apis', { method: 'POST', body: { token, provider } });
  if (!r.ok) return toast('❌ ' + r.message, 'error');
  $('add-api-token').value = '';
  toast('✅ API ditambahkan', 'success');
  loadApis();
};

window.deleteApi = async (id) => {
  if (!confirm('Hapus API#' + id + '?')) return;
  const r = await api('/api/apis/' + id, { method: 'DELETE' });
  toast(r.ok ? '✅ API dihapus' : ('❌ ' + r.message), r.ok ? 'success' : 'error');
  loadApis();
};

// ---- Install RDP ----
async function loadInstallApis() {
  const r = await api('/api/apis');
  const sel = $('install-api');
  if (!r.ok || !r.apis.length) { sel.innerHTML = '<option value="">Belum ada API</option>'; return; }
  sel.innerHTML = r.apis.map(a => `<option value="${a.id}">${a.provider || 'DigitalOcean'} API#${a.id} • ${a.email || '-'}</option>`).join('');
  sel.onchange = loadRegions;
  await loadWindows();
  await loadRegions();
}

async function loadWindows() {
  const r = await api('/api/windows');
  const sel = $('install-windows');
  if (r.ok) sel.innerHTML = r.windows.map(w => `<option value="${w.index}">${w.name}</option>`).join('');
}

async function loadRegions() {
  const apiId = $('install-api').value;
  if (!apiId) return;
  const sel = $('install-region');
  sel.innerHTML = '<option>Memuat...</option>';
  const r = await api('/api/regions?apiId=' + apiId);
  if (!r.ok || !r.regions || !r.regions.length) { sel.innerHTML = '<option value="">Gagal / kosong</option>'; return; }
  sel.innerHTML = r.regions.map(rg => {
    const slug = rg.slug || rg.id || rg;
    const name = rg.name || slug;
    return `<option value="${slug}">${name}</option>`;
  }).join('');
  sel.onchange = loadSizes;
  await loadSizes();
}

async function loadSizes() {
  const apiId = $('install-api').value;
  const region = $('install-region').value;
  if (!apiId || !region) return;
  const sel = $('install-size');
  sel.innerHTML = '<option>Memuat...</option>';
  const r = await api(`/api/sizes?apiId=${apiId}&region=${encodeURIComponent(region)}`);
  if (!r.ok || !r.sizes || !r.sizes.length) { sel.innerHTML = '<option value="">Gagal / kosong</option>'; return; }
  sel.innerHTML = r.sizes.map(s => {
    const slug = s.slug || s.id || s;
    const label = s.label || s.description || slug;
    return `<option value="${slug}">${label}</option>`;
  }).join('');
}

$('install-form').onsubmit = async (e) => {
  e.preventDefault();
  const body = {
    apiId: $('install-api').value,
    region: $('install-region').value,
    sizeSlug: $('install-size').value,
    winIndex: $('install-windows').value
  };
  if (!body.apiId || !body.region || !body.sizeSlug) return toast('Lengkapi form dulu.', 'error');
  const r = await api('/api/install-rdp', { method: 'POST', body });
  if (!r.ok) return toast('❌ ' + r.message, 'error');
  pollInstall(r.jobId);
};

function pollInstall(jobId) {
  const box = $('install-progress');
  box.classList.remove('hidden');
  if (pollTimer) clearInterval(pollTimer);
  const render = (j) => {
    if (j.status === 'done') {
      box.innerHTML = `<div class="step">✅ <strong>RDP siap!</strong></div>
        <div class="item-sub">IP: <code>${j.ip}:${j.rdpPort}</code><br>User: <code>administrator</code><br>Password: <code>${j.rdpPassword || '(lihat di VPS/RDP Saya)'}</code></div>`;
      clearInterval(pollTimer);
      loadServers();
    } else if (j.status === 'failed') {
      box.innerHTML = `<div class="step">❌ <strong>Gagal:</strong> ${j.error || 'Unknown'}</div>`;
      clearInterval(pollTimer);
    } else {
      box.innerHTML = `<div class="step"><span class="spinner"></span> ${j.step || j.status}</div>
        ${j.ip ? `<div class="item-sub">IP: <code>${j.ip}</code></div>` : ''}`;
    }
  };
  const tick = async () => {
    const r = await api('/api/install-rdp/' + jobId);
    if (r.ok) render(r);
  };
  tick();
  pollTimer = setInterval(tick, 5000);
}

// ---- Boot ----
enterApp();
