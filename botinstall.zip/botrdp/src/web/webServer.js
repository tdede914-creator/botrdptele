// ============================================================================
// webServer.js — Website untuk renter & admin (TANPA produk digital).
// Fitur: login via Telegram, kelola API cloud sendiri, lihat VPS/RDP milik
// sendiri, install RDP baru, TURN ON/OFF + cek status akun cloud.
//
// Berbagi rdp.db yang sama dengan bot (lewat renterManager & database.js),
// jadi status renter/instance selalu sinkron dengan bot Telegram.
//
// Jalankan: `npm run web`  (port dari WEB_PORT, default 3100).
// ============================================================================

require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');

const renterManager = require('../utils/renterManager');
const {
  powerDroplet, getAccountInfo, getRegions, getSizesForRegion,
  isLinodeToken, isAwsToken, isUpCloudToken, providerName
} = require('../utils/doApi');
const auth = require('./webAuth');
const installer = require('./webInstaller');

const app = express();
const PORT = Number(process.env.WEB_PORT || 3100);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// ---- Helpers ----------------------------------------------------------------
function ok(res, data = {}) { return res.json({ ok: true, ...data }); }
function fail(res, message, code = 400) { return res.status(code).json({ ok: false, message }); }

async function checkCloudStatus(token) {
  try {
    const info = await getAccountInfo(token);
    if (info && info.ok) return { ok: true, label: 'Aktif', email: info.account?.email || '-' };
    const c = info?.statusCode;
    const reason = (c === 401 || c === 403) ? 'token invalid/dicabut' : (info?.error || 'tidak bisa diverifikasi');
    return { ok: false, label: 'Bermasalah', reason };
  } catch (e) {
    return { ok: false, label: 'Bermasalah', reason: e.message || 'error' };
  }
}

// ---- Auth routes ------------------------------------------------------------
app.post('/api/auth/request-code', async (req, res) => {
  try {
    const r = await auth.requestLoginCode(req.body.identifier);
    if (!r.ok) return fail(res, r.message);
    return ok(res, { userId: r.userId, message: r.message });
  } catch (e) { return fail(res, e.message || 'Error', 500); }
});

app.post('/api/auth/verify-code', async (req, res) => {
  try {
    const r = await auth.verifyLoginCode(req.body.userId, req.body.code);
    if (!r.ok) return fail(res, r.message);
    res.cookie('sid', r.token, { httpOnly: true, sameSite: 'lax', maxAge: 24 * 60 * 60 * 1000 });
    return ok(res, { isAdmin: r.isAdmin });
  } catch (e) { return fail(res, e.message || 'Error', 500); }
});

app.post('/api/auth/logout', auth.requireAuth, (req, res) => {
  auth.destroySession(req.cookies.sid);
  res.clearCookie('sid');
  return ok(res);
});

app.get('/api/me', auth.requireAuth, async (req, res) => {
  const renter = await renterManager.getRenter(req.user.userId);
  return ok(res, {
    userId: req.user.userId,
    isAdmin: req.user.isAdmin,
    username: renter?.username || null,
    expiresAt: renter?.expires_at || null,
    tier: renter?.tier || 'basic'
  });
});

// ---- API cloud (milik user sendiri) ----------------------------------------
app.get('/api/apis', auth.requireAuth, async (req, res) => {
  const apis = await renterManager.listApis(req.user.userId);
  return ok(res, { apis });
});

app.post('/api/apis', auth.requireAuth, async (req, res) => {
  try {
    const { token, provider } = req.body;
    if (!token) return fail(res, 'Token wajib diisi.');
    await renterManager.addApi(req.user.userId, token, provider || 'digitalocean');
    return ok(res);
  } catch (e) { return fail(res, e.message || 'Gagal menambah API'); }
});

app.delete('/api/apis/:id', auth.requireAuth, async (req, res) => {
  try {
    await renterManager.deleteApi(req.user.userId, Number(req.params.id));
    return ok(res);
  } catch (e) { return fail(res, e.message || 'Gagal menghapus API'); }
});

// Cek status akun cloud untuk 1 API milik user.
app.get('/api/apis/:id/status', auth.requireAuth, async (req, res) => {
  const token = await renterManager.getApiToken(req.user.userId, Number(req.params.id));
  if (!token) return fail(res, 'API tidak ditemukan.', 404);
  const st = await checkCloudStatus(token);
  return ok(res, { status: st });
});

// ---- Instances (VPS/RDP milik user sendiri) --------------------------------
app.get('/api/instances', auth.requireAuth, async (req, res) => {
  let rows = await renterManager.listInstances(req.user.userId);
  if (req.query.apiId) {
    const apiId = String(req.query.apiId);
    rows = rows.filter(x => String(x.api_id != null ? x.api_id : 'none') === apiId);
  }
  const instances = rows.map(x => ({
    id: x.id, type: x.type, ip: x.ip, droplet_id: x.droplet_id,
    api_id: x.api_id, size_slug: x.size_slug, region: x.region,
    rdp_port: x.rdp_port || 4443, windows_version: x.windows_version
  }));
  return ok(res, { instances });
});

// TURN ON / OFF — scoped ke user & API miliknya.
app.post('/api/instances/:id/power', auth.requireAuth, async (req, res) => {
  try {
    const action = req.body.action === 'on' ? 'on' : 'off';
    const x = await renterManager.getInstance(req.user.userId, Number(req.params.id));
    if (!x || !x.droplet_id) return fail(res, 'Data VPS/RDP tidak ditemukan.', 404);
    const token = x.api_id
      ? await renterManager.getApiToken(req.user.userId, x.api_id)
      : await renterManager.getDefaultApiToken(req.user.userId);
    if (!token) return fail(res, 'API asal VPS/RDP tidak ditemukan.');
    const result = await powerDroplet(token, x.droplet_id, action, x.region);
    if (!result.ok) return fail(res, result.error || 'Gagal power action');
    return ok(res, { action });
  } catch (e) { return fail(res, e.message || 'Error', 500); }
});

// ---- Install RDP baru -------------------------------------------------------
app.get('/api/windows', auth.requireAuth, (req, res) => {
  const list = installer.getWindowsList().map((os, i) => ({ index: i, name: os.name, version: os.version }));
  return ok(res, { windows: list });
});

app.get('/api/regions', auth.requireAuth, async (req, res) => {
  try {
    const token = await renterManager.getApiToken(req.user.userId, Number(req.query.apiId));
    if (!token) return fail(res, 'API tidak ditemukan.', 404);
    const regions = await getRegions(token);
    return ok(res, { regions });
  } catch (e) { return fail(res, e.message || 'Gagal ambil region'); }
});

app.get('/api/sizes', auth.requireAuth, async (req, res) => {
  try {
    const token = await renterManager.getApiToken(req.user.userId, Number(req.query.apiId));
    if (!token) return fail(res, 'API tidak ditemukan.', 404);
    const sizes = await getSizesForRegion(token, req.query.region);
    return ok(res, { sizes });
  } catch (e) { return fail(res, e.message || 'Gagal ambil size'); }
});

app.post('/api/install-rdp', auth.requireAuth, async (req, res) => {
  try {
    const { apiId, sizeSlug, region, winIndex } = req.body;
    if (!apiId || !sizeSlug || !region || winIndex == null) return fail(res, 'Data tidak lengkap.');
    const { jobId } = await installer.startRdpInstall({
      userId: req.user.userId, apiId: Number(apiId), sizeSlug, region, winIndex: Number(winIndex)
    });
    return ok(res, { jobId });
  } catch (e) { return fail(res, e.message || 'Gagal memulai install'); }
});

app.get('/api/install-rdp/:jobId', auth.requireAuth, (req, res) => {
  const job = installer.getJob(req.params.jobId);
  if (!job) return fail(res, 'Job tidak ditemukan.', 404);
  if (Number(job.userId) !== Number(req.user.userId)) return fail(res, 'Bukan job milikmu.', 403);
  return ok(res, {
    status: job.status, step: job.step, ip: job.ip, error: job.error,
    rdpPort: job.rdpPort, rdpPassword: job.status === 'done' ? job.rdpPassword : undefined
  });
});

// SPA fallback -> index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`🌐 Web server jalan di http://localhost:${PORT}`);
  if (!process.env.TELEGRAM_BOT_TOKEN) console.warn('⚠️  TELEGRAM_BOT_TOKEN belum diset — login via Telegram tidak akan bekerja.');
});

module.exports = app;
