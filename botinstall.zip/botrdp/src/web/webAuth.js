// ============================================================================
// webAuth.js — Login WEBSITE via Telegram.
// Renter yang sudah terdaftar di bot (tabel `renters`) login di web dengan
// memasukkan username Telegram / user_id, lalu memasukkan KODE yang dikirim
// bot ke akun Telegram-nya. Tidak ada password terpisah — identitas mengikuti
// keanggotaan renter di bot.
//
// Catatan: bot mengirim kode via Telegram Bot API (token sama dengan bot).
// Web dan bot berbagi file rdp.db yang sama, jadi status renter selalu sinkron.
// ============================================================================

const crypto = require('crypto');
const axios = require('axios');
const renterManager = require('../utils/renterManager');
const db = require('../config/database');

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const ADMIN_ID = process.env.ADMIN_ID;

// Kode login pending: key = userId, value = { code, expiresAt, tries }
const pendingCodes = new Map();
// Session aktif: key = sessionToken, value = { userId, isAdmin, createdAt }
const sessions = new Map();

const CODE_TTL_MS = 5 * 60 * 1000;      // kode berlaku 5 menit
const SESSION_TTL_MS = 24 * 60 * 60 * 1000; // sesi 24 jam
const MAX_TRIES = 5;

function nowSec() { return Math.floor(Date.now() / 1000); }

// Cari renter berdasarkan input: bisa user_id (angka) atau username (@handle).
async function findRenterByIdentifier(identifier) {
  const raw = String(identifier || '').trim();
  if (!raw) return null;
  if (/^\d+$/.test(raw)) {
    return await renterManager.getRenter(Number(raw));
  }
  const uname = raw.replace(/^@/, '').toLowerCase();
  // renters.username disimpan saat interaksi bot; cocokkan case-insensitive.
  return await db.get(
    'SELECT * FROM renters WHERE LOWER(REPLACE(username, "@", "")) = ? LIMIT 1',
    [uname]
  );
}

function isActiveRenterRow(row) {
  return !!(row && Number(row.expires_at) > nowSec());
}

async function sendTelegramCode(userId, code) {
  if (!BOT_TOKEN) throw new Error('Bot token belum dikonfigurasi.');
  const text = `🔐 Kode login website kamu: *${code}*\n\nBerlaku 5 menit. Jangan bagikan kode ini ke siapa pun.`;
  await axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
    chat_id: userId,
    text,
    parse_mode: 'Markdown'
  }, { timeout: 15000 });
}

// Langkah 1: minta kode login. Kirim kode ke Telegram user kalau dia renter aktif
// (atau admin). Return { ok, userId, message } — userId dipakai di langkah verifikasi.
async function requestLoginCode(identifier) {
  const isAdminId = String(identifier).trim() === String(ADMIN_ID);
  let userId;
  if (isAdminId) {
    userId = Number(ADMIN_ID);
  } else {
    const row = await findRenterByIdentifier(identifier);
    if (!row) return { ok: false, message: 'Akun tidak ditemukan. Pastikan kamu sudah jadi renter di bot Telegram.' };
    if (!isActiveRenterRow(row)) return { ok: false, message: 'Masa sewa (renter) sudah habis. Perpanjang dulu di bot.' };
    userId = Number(row.user_id);
  }

  const code = String(crypto.randomInt(100000, 999999));
  pendingCodes.set(userId, { code, expiresAt: Date.now() + CODE_TTL_MS, tries: 0 });
  try {
    await sendTelegramCode(userId, code);
  } catch (e) {
    // Umumnya karena user belum pernah /start ke bot (tidak bisa dikirimi pesan).
    pendingCodes.delete(userId);
    return { ok: false, message: 'Gagal mengirim kode ke Telegram. Pastikan kamu sudah pernah chat /start ke bot.' };
  }
  return { ok: true, userId, message: 'Kode login sudah dikirim ke Telegram kamu.' };
}

// Langkah 2: verifikasi kode. Kalau cocok, buat session dan return token.
async function verifyLoginCode(userId, code) {
  const uid = Number(userId);
  const pending = pendingCodes.get(uid);
  if (!pending) return { ok: false, message: 'Tidak ada permintaan kode. Minta kode dulu.' };
  if (Date.now() > pending.expiresAt) { pendingCodes.delete(uid); return { ok: false, message: 'Kode kadaluarsa. Minta kode baru.' }; }
  if (pending.tries >= MAX_TRIES) { pendingCodes.delete(uid); return { ok: false, message: 'Terlalu banyak percobaan. Minta kode baru.' }; }
  pending.tries += 1;
  if (String(code).trim() !== pending.code) return { ok: false, message: 'Kode salah.' };

  pendingCodes.delete(uid);
  const isAdmin = String(uid) === String(ADMIN_ID);
  const token = crypto.randomBytes(24).toString('hex');
  sessions.set(token, { userId: uid, isAdmin, createdAt: Date.now() });
  return { ok: true, token, isAdmin };
}

function getSession(token) {
  const s = sessions.get(token);
  if (!s) return null;
  if (Date.now() - s.createdAt > SESSION_TTL_MS) { sessions.delete(token); return null; }
  return s;
}

function destroySession(token) {
  sessions.delete(token);
}

// Express middleware: wajib login.
function requireAuth(req, res, next) {
  const token = req.cookies?.sid;
  const s = token ? getSession(token) : null;
  if (!s) return res.status(401).json({ ok: false, message: 'Belum login.' });
  req.user = s;
  next();
}

// Bersihkan session/kode kadaluarsa berkala.
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of pendingCodes) if (now > v.expiresAt) pendingCodes.delete(k);
  for (const [k, v] of sessions) if (now - v.createdAt > SESSION_TTL_MS) sessions.delete(k);
}, 60 * 1000).unref();

module.exports = { requestLoginCode, verifyLoginCode, getSession, destroySession, requireAuth };
