// ============================================================================
// webStore.js — ETALASE jual RDP lewat WEBSITE (seperti order di bot).
//
// Sumber jualan = pool ADMIN (do_api + vps_products) — sama persis dengan yang
// dijual bot. Uang = users.balance yang sama. Instance ditulis ke vps_instances
// yang sama, sehingga "RDP Saya" di web = "VPS/RDP Saya" di bot.
//
// Dua metode bayar:
//   - saldo : wajib login, potong users.balance, langsung provisioning.
//   - qris  : bisa anonim (isi Telegram ID), buat pembayaran gateway, tahan
//             slot, poller cek status; begitu lunas -> provisioning.
//
// Status order disimpan di tabel web_orders (sumber kebenaran) supaya halaman
// web TAHAN REFRESH & TAHAN RESTART server, sekaligus jadi riwayat order admin.
//
// Provisioning + install reuse building block bot (createDroplet, waitPublicIp,
// installDedicatedRDP, linodeAutoDirectDisk, RDPMonitor) => hasil identik bot,
// termasuk verifikasi port RDP + fix Linode Direct Disk.
// ============================================================================

const crypto = require('crypto');
const net = require('net');
const QRCode = require('qrcode');

const db = require('../config/database');
const vpsManager = require('../utils/vpsManager');
const userManager = require('../utils/userManager');
const webNotify = require('./webNotify');
const { createPayment, checkPaymentStatus, cancelPayment, isPaymentStatusSuccessful } = require('../utils/payment');
const {
  createDroplet, waitPublicIp, deleteDroplet,
  isLinodeToken, isAwsToken, isUpCloudToken,
  providerName, linodeAutoDirectDisk, rdpPortForToken, getRegions
} = require('../utils/doApi');
const { installDedicatedRDP } = require('../utils/dedicatedRdpInstaller');
const RDPMonitor = require('../utils/rdpMonitor');
const { RDP_MONITOR_TIMEOUT_MS } = require('../utils/rdpPasswordUtil');
const { getWindowsList } = require('./webInstaller');

const PRODUCT_TYPE = 'rdp';
const POLL_INTERVAL_MS = 12000;

// ---------------------------------------------------------------------------
// Util kecil (pola sama dengan webInstaller / rdpOrderHandler).
// ---------------------------------------------------------------------------
const now = () => Math.floor(Date.now() / 1000);

function genAlphaNum(n = 18) {
  const raw = crypto.randomBytes(48).toString('base64').replace(/[\/+=]/g, '');
  const body = raw.slice(0, Math.max(12, Number(n) || 18));
  return `${body}-KCSERVER-143`;
}

function genWindowsPassword() {
  for (let i = 0; i < 50; i++) {
    const p = genAlphaNum(14);
    if (/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{10,}$/.test(p)) return p;
  }
  return `Win${Date.now()}A1`;
}

function rootCloudInit(password) {
  return `#cloud-config
ssh_pwauth: true
disable_root: false
chpasswd:
  list: |
    root:${password}
  expire: false
write_files:
  - path: /etc/ssh/sshd_config.d/99-root-password.conf
    permissions: '0644'
    content: |
      PermitRootLogin yes
      PasswordAuthentication yes
      KbdInteractiveAuthentication yes
runcmd:
  - [ sh, -lc, "set -e; (grep -q '^PermitRootLogin' /etc/ssh/sshd_config && sed -i 's/^PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config || echo 'PermitRootLogin yes' >> /etc/ssh/sshd_config); (grep -q '^PasswordAuthentication' /etc/ssh/sshd_config && sed -i 's/^PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config || echo 'PasswordAuthentication yes' >> /etc/ssh/sshd_config); (grep -q '^KbdInteractiveAuthentication' /etc/ssh/sshd_config && sed -i 's/^KbdInteractiveAuthentication.*/KbdInteractiveAuthentication yes/' /etc/ssh/sshd_config || echo 'KbdInteractiveAuthentication yes' >> /etc/ssh/sshd_config); systemctl restart ssh || systemctl restart sshd || service ssh restart || true" ]
`;
}

function normalizeAwsRdpSize(sizeSlug) {
  const size = String(sizeSlug || '');
  const map = {
    't3.micro': 't2.micro', 't3.small': 't2.small', 't3.medium': 't2.medium',
    't3.large': 't2.large', 't3.xlarge': 't2.xlarge',
    'm5.large': 't2.large', 'm5.xlarge': 't2.xlarge'
  };
  return map[size] || size;
}

async function waitForPort(host, port, totalMs = 12 * 60 * 1000, intervalMs = 15000) {
  const start = Date.now();
  const tryOnce = () => new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; try { socket.destroy(); } catch (_) {} resolve(ok); };
    socket.setTimeout(5000);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
  while (Date.now() - start < totalMs) {
    if (await tryOnce()) return true;
    await new Promise(r => setTimeout(r, intervalMs));
  }
  return false;
}

function normalizeDuration(d) {
  const n = Number(d);
  if (n === 1 || n === 7) return n;
  return 30;
}

function priceForDuration(product, d) {
  if (d === 1) return product.price_daily;
  if (d === 7) return product.price_weekly;
  return product.price;
}

function durationLabel(d) {
  if (d === 1) return 'Harian';
  if (d === 7) return 'Mingguan';
  if (d === 30) return 'Bulanan';
  return `${d} hari`;
}

// ---------------------------------------------------------------------------
// DB helper untuk web_orders.
// ---------------------------------------------------------------------------
async function insertOrder(o) {
  const res = await db.run(
    `INSERT INTO web_orders
       (public_token, user_id, telegram_input, product_id, api_id, duration_days,
        region, os_version, os_name, size_slug, price, pay_method, pay_ref,
        qr_string, qr_image, status, step, slot_reserved, created_at, updated_at, expire_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [
      o.public_token, o.user_id, o.telegram_input, o.product_id, o.api_id, o.duration_days,
      o.region, o.os_version, o.os_name, o.size_slug, o.price, o.pay_method, o.pay_ref || null,
      o.qr_string || null, o.qr_image || null, o.status, o.step, o.slot_reserved ? 1 : 0,
      o.created_at, o.updated_at, o.expire_at || null
    ]
  );
  return res.id;
}

async function patchOrder(id, patch) {
  const data = { ...patch, updated_at: now() };
  const cols = Object.keys(data);
  if (!cols.length) return;
  const sets = cols.map(k => `${k} = ?`).join(', ');
  const vals = cols.map(k => data[k]);
  vals.push(id);
  await db.run(`UPDATE web_orders SET ${sets} WHERE id = ?`, vals);
}

async function getOrderRow(id) {
  return await db.get('SELECT * FROM web_orders WHERE id = ?', [id]);
}

function toView(o) {
  if (!o) return null;
  const port = o.rdp_port || 3389;
  const address = o.ip ? (port && port !== 3389 ? `${o.ip}:${port}` : o.ip) : null;
  return {
    id: o.id,
    publicToken: o.public_token,
    status: o.status,
    step: o.step,
    payMethod: o.pay_method,
    price: o.price,
    durationDays: o.duration_days,
    durationLabel: durationLabel(o.duration_days),
    region: o.region,
    osName: o.os_name,
    ip: o.ip || null,
    rdpPort: o.rdp_port || null,
    address,
    username: o.rdp_password ? 'Administrator' : null,
    rdpPassword: o.rdp_password || null,
    qrImage: (o.status === 'awaiting_payment') ? (o.qr_image || null) : null,
    qrString: (o.status === 'awaiting_payment') ? (o.qr_string || null) : null,
    expireAt: o.expire_at || null,
    error: o.error || null,
    userId: o.user_id || null,
    createdAt: o.created_at
  };
}

// ---------------------------------------------------------------------------
// Katalog & pilihan.
// ---------------------------------------------------------------------------
async function getCatalog(durationDays) {
  const d = normalizeDuration(durationDays);
  const groups = await vpsManager.listActiveProductGroupsByDuration(PRODUCT_TYPE, d);
  return {
    duration: d,
    durationLabel: durationLabel(d),
    products: (groups || []).map(g => ({
      ram: g.ram,
      core: g.core,
      price: g.price,
      slot: g.slot,
      label: `${g.ram}GB RAM • ${g.core} vCPU`
    }))
  };
}

function getOsList() {
  return getWindowsList().map((os, index) => ({ index, name: os.name, version: os.version }));
}

// Resolusi region: pilih produk terbaik untuk spek+durasi, ambil token API
// aktifnya, lalu daftar region provider tsb. Kembalikan productId supaya
// checkout memakai produk yang sama.
async function resolveRegions({ ram, core, duration }) {
  const d = normalizeDuration(duration);
  const products = await vpsManager.listActiveProductsByGroupDuration(PRODUCT_TYPE, ram, core, d);
  if (!products || !products.length) {
    const err = new Error('Stok untuk paket ini sedang habis.');
    err.code = 'OUT_OF_STOCK';
    throw err;
  }
  // Cari produk pertama yang tokennya aktif.
  let chosen = null, token = null;
  for (const p of products) {
    const t = await vpsManager.getDoApiToken(p.api_id);
    if (t) { chosen = p; token = t; break; }
  }
  if (!chosen) {
    const err = new Error('API untuk paket ini sedang nonaktif. Coba lagi nanti.');
    err.code = 'NO_ACTIVE_API';
    throw err;
  }
  let regions = [];
  try {
    const raw = await getRegions(token);
    regions = (raw || []).map(r => ({ slug: r.slug || r.id, name: r.name || r.slug || r.id }))
      .filter(r => r.slug);
  } catch (e) {
    const err = new Error('Gagal memuat daftar region: ' + (e.message || e));
    err.code = 'REGION_FAIL';
    throw err;
  }
  return {
    productId: chosen.id,
    apiId: chosen.api_id,
    sizeSlug: chosen.size_slug,
    price: priceForDuration(await vpsManager.getProduct(chosen.id), d),
    provider: providerName(token),
    regions
  };
}

// ---------------------------------------------------------------------------
// Checkout.
// ---------------------------------------------------------------------------
async function checkout({ session, productId, ram, core, duration, region, osIndex, payMethod, telegram }) {
  const d = normalizeDuration(duration);
  const method = String(payMethod || '').toLowerCase();
  if (method !== 'qris' && method !== 'saldo') throw new Error('Metode bayar tidak valid (pilih qris / saldo).');

  // Resolusi produk.
  let product = null;
  if (productId) {
    product = await vpsManager.getProduct(productId);
  }
  if (!product && ram != null && core != null) {
    const list = await vpsManager.listActiveProductsByGroupDuration(PRODUCT_TYPE, ram, core, d);
    if (list && list.length) product = await vpsManager.getProduct(list[0].id);
  }
  if (!product) throw new Error('Produk tidak ditemukan / sudah tidak dijual.');
  if (product.product_type && product.product_type !== PRODUCT_TYPE) throw new Error('Produk bukan RDP.');

  const price = priceForDuration(product, d);
  if (price == null || Number(price) <= 0) throw new Error('Harga paket untuk durasi ini belum diset.');

  // OS.
  const osList = getWindowsList();
  const selectedOS = osList[Number(osIndex)];
  if (!selectedOS) throw new Error('OS Windows tidak valid.');

  const regionSlug = String(region || '').trim();
  if (!regionSlug) throw new Error('Region belum dipilih.');

  // Identitas pembeli.
  let userId = null;
  let telegramInput = null;
  if (session && session.userId) {
    userId = session.userId;
  } else {
    telegramInput = String(telegram || '').trim();
    const digits = telegramInput.replace(/[^\d]/g, '');
    if (method === 'saldo') throw new Error('Bayar via saldo harus login dulu.');
    if (!/^\d{5,}$/.test(digits)) {
      throw new Error('Masukkan ID Telegram numerik (contoh: 123456789) agar kredensial dikirim ke Telegram. Dapatkan dari @userinfobot.');
    }
    userId = Number(digits);
    await userManager.getUser(userId); // pastikan baris users ada
  }

  const baseOrder = {
    public_token: crypto.randomBytes(16).toString('hex'),
    user_id: userId,
    telegram_input: telegramInput,
    product_id: product.id,
    api_id: product.api_id,
    duration_days: d,
    region: regionSlug,
    os_version: selectedOS.version,
    os_name: selectedOS.name,
    size_slug: product.size_slug,
    price: Number(price),
    pay_method: method,
    created_at: now(),
    updated_at: now()
  };

  if (method === 'saldo') {
    return await checkoutSaldo(baseOrder, product);
  }
  return await checkoutQris(baseOrder, product);
}

async function checkoutSaldo(baseOrder, product) {
  // Reserve slot terkonfirmasi (anti oversell).
  const reserved = await vpsManager.tryReserveProductSlotDuration(product.id, baseOrder.duration_days);
  if (!reserved) throw new Error('Stok untuk paket ini baru saja habis.');

  // Potong saldo (admin => true tanpa potong).
  let deducted;
  try {
    deducted = await userManager.deductBalance(baseOrder.user_id, baseOrder.price);
  } catch (e) {
    await safeReleaseSlot(product.id, baseOrder.duration_days);
    throw new Error('Gagal memproses saldo: ' + (e.message || e));
  }
  if (!deducted) {
    await safeReleaseSlot(product.id, baseOrder.duration_days);
    throw new Error('Saldo tidak mencukupi. Silakan top-up dulu.');
  }

  const orderId = await insertOrder({
    ...baseOrder,
    status: 'provisioning',
    step: 'Pembayaran saldo diterima, menyiapkan VPS...',
    slot_reserved: 1
  });

  runProvision(orderId).catch(e => console.error('[webStore] provision(saldo) error:', e.message || e));
  const row = await getOrderRow(orderId);
  return { orderId, publicToken: row.public_token, status: row.status, view: toView(row) };
}

async function checkoutQris(baseOrder, product) {
  // Reserve slot dulu supaya tidak oversell selama menunggu QRIS.
  const reserved = await vpsManager.tryReserveProductSlotDuration(product.id, baseOrder.duration_days);
  if (!reserved) throw new Error('Stok untuk paket ini baru saja habis.');

  let pay;
  const reff = `WEBRDP${Date.now()}${baseOrder.user_id || 'X'}`;
  try {
    pay = await createPayment(process.env.DOMPETX_API_KEY, reff, baseOrder.price);
  } catch (e) {
    await safeReleaseSlot(product.id, baseOrder.duration_days);
    throw new Error('Gagal membuat pembayaran QRIS: ' + (e.message || e));
  }
  if (!pay || !pay.success || !pay.data || !pay.data.qr_string) {
    await safeReleaseSlot(product.id, baseOrder.duration_days);
    throw new Error((pay && pay.error) || 'QRIS tidak tersedia dari gateway.');
  }

  // QR data-URL untuk <img> di web (dari qr_string, paling andal).
  let qrImage = null;
  try {
    qrImage = await QRCode.toDataURL(pay.data.qr_string, { width: 360, margin: 2 });
  } catch (_) {
    qrImage = pay.data.qr_image || null;
  }
  const expireAt = pay.data.expired_at
    ? Math.floor(new Date(pay.data.expired_at).getTime() / 1000)
    : now() + 30 * 60;

  const orderId = await insertOrder({
    ...baseOrder,
    pay_ref: pay.data.id,
    qr_string: pay.data.qr_string,
    qr_image: qrImage,
    status: 'awaiting_payment',
    step: 'Menunggu pembayaran QRIS...',
    slot_reserved: 1,
    expire_at: expireAt
  });

  armPoller(orderId);
  const row = await getOrderRow(orderId);
  return { orderId, publicToken: row.public_token, status: row.status, view: toView(row) };
}

async function safeReleaseSlot(productId, durationDays) {
  try { await vpsManager.incrementProductSlotDuration(productId, durationDays); } catch (e) {
    console.error('[webStore] release slot gagal:', e.message || e);
  }
}

// ---------------------------------------------------------------------------
// Poller QRIS (in-memory; di-resume saat init).
// ---------------------------------------------------------------------------
const pollers = new Map(); // orderId -> intervalId

function armPoller(orderId) {
  if (pollers.has(orderId)) return;
  const t = setInterval(() => {
    pollTick(orderId).catch(e => console.error('[webStore] pollTick error:', e.message || e));
  }, POLL_INTERVAL_MS);
  pollers.set(orderId, t);
}

function clearPoller(orderId) {
  const t = pollers.get(orderId);
  if (t) { clearInterval(t); pollers.delete(orderId); }
}

async function pollTick(orderId) {
  const order = await getOrderRow(orderId);
  if (!order) { clearPoller(orderId); return; }
  if (order.status !== 'awaiting_payment') { clearPoller(orderId); return; }

  // Kedaluwarsa -> lepas slot + batalkan pembayaran.
  if (order.expire_at && now() > order.expire_at) {
    clearPoller(orderId);
    await patchOrder(orderId, { status: 'expired', step: 'Pembayaran kedaluwarsa.', slot_reserved: 0 });
    await safeReleaseSlot(order.product_id, order.duration_days);
    try { await cancelPayment(order.pay_ref); } catch (_) {}
    return;
  }

  let st;
  try {
    st = await checkPaymentStatus(process.env.DOMPETX_API_KEY, order.pay_ref);
  } catch (e) {
    return; // coba lagi tick berikutnya
  }
  if (st && st.success && isPaymentStatusSuccessful(st.data)) {
    clearPoller(orderId);
    await patchOrder(orderId, { status: 'paid', step: 'Pembayaran diterima, menyiapkan VPS...' });
    runProvision(orderId).catch(e => console.error('[webStore] provision(qris) error:', e.message || e));
  }
}

// ---------------------------------------------------------------------------
// Pipeline provisioning + install (dipakai saldo & qris).
// ---------------------------------------------------------------------------
async function runProvision(orderId) {
  const order = await getOrderRow(orderId);
  if (!order) return;
  if (['done', 'failed', 'expired'].includes(order.status)) return;

  const product = await vpsManager.getProduct(order.product_id);
  const token = await vpsManager.getDoApiTokenAny(order.api_id);
  if (!token) {
    await failBeforeInstance(order, 'API tidak tersedia untuk menyelesaikan order.');
    return;
  }

  await patchOrder(orderId, { status: 'provisioning', step: 'Membuat VPS...' });

  let instanceCreated = false;
  try {
    const rootPass = genAlphaNum(12);
    const rdpPass = genWindowsPassword();
    const hostname = `web-rdp-${order.user_id || 'anon'}-${genAlphaNum(6).toLowerCase()}`;
    const cloudInit = rootCloudInit(rootPass);
    const baseImage = isAwsToken(token) ? 'aws:ubuntu22.04'
      : (isLinodeToken(token) ? 'linode/ubuntu22.04'
      : (isUpCloudToken(token) ? 'upcloud/ubuntu22.04' : 'ubuntu-22-04-x64'));
    const createSizeSlug = isAwsToken(token) ? normalizeAwsRdpSize(order.size_slug) : order.size_slug;

    const createRes = await createDroplet(token, hostname, order.region, createSizeSlug, baseImage, cloudInit);
    const { dropletId, error, sshPrivateKey, sshUsername } = createRes || {};
    if (!dropletId) {
      await failBeforeInstance(order, error || 'Gagal membuat VPS.');
      return;
    }
    await patchOrder(orderId, { status: 'provisioning', step: 'Menunggu VPS aktif & IP...', droplet_id: dropletId });

    const ip = await waitPublicIp(token, dropletId, 20, 10000, order.region);
    if (!ip) {
      try { await deleteDroplet(token, dropletId, order.region); } catch (_) {}
      await failBeforeInstance(order, 'VPS tidak mendapat IP. Silakan coba lagi.');
      return;
    }

    const rdpPort = rdpPortForToken(token);
    const expiresAt = now() + order.duration_days * 86400;
    await vpsManager.createVpsInstance({
      userId: order.user_id,
      apiId: order.api_id,
      productId: product.id,
      dropletId,
      ip,
      region: order.region,
      image: `rdp:${order.os_version}`,
      rootPassword: rdpPass,          // simpan password RDP (Windows), sama seperti bot
      expiresAt,
      durationDays: order.duration_days,
      rdpPort
    });
    instanceCreated = true; // mulai titik ini TIDAK ada refund (VPS sudah jadi)

    await patchOrder(orderId, {
      status: 'installing',
      step: 'Menginstall Windows (15-25 menit)...',
      ip, rdp_port: rdpPort, rdp_password: rdpPass
    });

    const sshReady = await waitForPort(ip, 22, 12 * 60 * 1000, 15000);
    if (!sshReady) {
      await patchOrder(orderId, { status: 'failed', step: 'Gagal', error: 'SSH tidak siap. VPS sudah dibuat — silakan rebuild dari bot (VPS/RDP Saya).' });
      await notifyBuyerFailKeepVps(order, ip, rdpPort, rdpPass);
      return;
    }

    // UpCloud auth via SSH key; provider lain via password root.
    const upcloudKey = (isUpCloudToken(token) && sshPrivateKey) ? sshPrivateKey : null;
    const sshUser = upcloudKey ? (sshUsername || 'root') : 'root';
    const installProvider = isAwsToken(token) ? 'aws' : (isLinodeToken(token) ? 'linode' : (isUpCloudToken(token) ? 'upcloud' : 'digitalocean'));
    const installCfg = { osVersion: order.os_version, password: rdpPass, provider: installProvider, rdpPort };
    if (upcloudKey) { installCfg.privateKey = upcloudKey; installCfg.useSudo = sshUser !== 'root'; }

    const installPromise = installDedicatedRDP(ip, sshUser, upcloudKey ? null : rootPass, installCfg, (log) => console.log(`[WEBSTORE ${ip}] ${log}`));

    // Fix Linode: Direct Disk adaptif (sama seperti bot).
    if (isLinodeToken(token)) {
      linodeAutoDirectDisk(token, dropletId, { log: (m) => console.log(`[WEBSTORE ${ip}] [DirectDisk] ${m}`) })
        .then(res => { if (!res.ok) console.warn(`[WEBSTORE ${ip}] Direct Disk TIDAK terverifikasi:`, res.error); })
        .catch(e => console.warn(`[WEBSTORE ${ip}] linodeAutoDirectDisk error:`, e.message || e));
    }

    await installPromise;

    // Verifikasi port RDP siap (upgrade vs installer web lama).
    const monitor = new RDPMonitor(ip, 'root', rootPass, rdpPass, rdpPort);
    let rdpResult = { success: false, rdpReady: false };
    try {
      rdpResult = await monitor.waitForRDPReady(RDP_MONITOR_TIMEOUT_MS, (s) => console.log(`[WEBSTORE ${ip}] ${s}`));
    } catch (e) {
      console.warn(`[WEBSTORE ${ip}] monitor error:`, e.message || e);
    } finally {
      try { monitor.disconnect(); } catch (_) {}
    }

    const finalOrder = await getOrderRow(orderId);
    if (rdpResult && rdpResult.success && rdpResult.rdpReady) {
      await patchOrder(orderId, { status: 'done', step: 'RDP siap digunakan!', error: null });
      await deliverSuccess(finalOrder, product);
    } else {
      // Timeout verifikasi — kredensial tetap diserahkan (seperti bot).
      await patchOrder(orderId, { status: 'done', step: 'RDP dibuat (verifikasi port melebihi waktu).', error: 'Verifikasi port RDP melebihi waktu; coba beberapa menit lagi.' });
      await deliverTimeout(finalOrder, product);
    }
  } catch (e) {
    console.error('[webStore] runProvision exception:', e.message || e);
    if (instanceCreated) {
      await patchOrder(orderId, { status: 'failed', step: 'Gagal saat instalasi', error: (e.message || 'Error') + ' — VPS sudah dibuat, rebuild via bot.' });
    } else {
      await failBeforeInstance(order, e.message || 'Gagal saat provisioning.');
    }
  }
}

// Gagal SEBELUM instance dibuat: lepas slot + refund/kompensasi uang.
async function failBeforeInstance(order, message) {
  await patchOrder(order.id, { status: 'failed', step: 'Gagal', error: message, slot_reserved: 0 });
  await safeReleaseSlot(order.product_id, order.duration_days);
  await refundIfPaid(order);
  // Beri tahu pembeli.
  const text = `❌ *Order RDP #${order.id} gagal*\n\n${message}\n\n` +
    (order.pay_method === 'saldo' ? '💰 Saldo kamu sudah dikembalikan.' : '💰 Dana akan dikompensasi ke saldo (jika pembayaran sudah masuk).');
  webNotify.notifyBuyer(order.user_id, text).catch(() => {});
}

async function refundIfPaid(order) {
  const fresh = await getOrderRow(order.id);
  if (!fresh || fresh.refunded) return;
  // saldo: selalu sudah dipotong di checkout (kecuali admin).
  // qris : hanya dikompensasi jika sudah lunas (status pernah paid/provisioning/installing).
  const qrisPaid = order.pay_method === 'qris' && ['paid', 'provisioning', 'installing'].includes(order.status);
  const saldoCharged = order.pay_method === 'saldo';
  const shouldRefund = (saldoCharged || qrisPaid) && order.user_id && !userManager.isAdmin(order.user_id);
  if (!shouldRefund) return;
  try {
    await userManager.addBalance(order.user_id, order.price);
    await patchOrder(order.id, { refunded: 1 });
  } catch (e) {
    console.error('[webStore] refund gagal:', e.message || e);
  }
}

async function deliverSuccess(order, product) {
  if (order.notify_sent) return;
  await patchOrder(order.id, { notify_sent: 1 });
  const card = webNotify.buildCredentialCard(order, product);
  webNotify.notifyBuyer(order.user_id, card).catch(() => {});
  webNotify.notifySaleToStaff(order, product).catch(() => {});
}

async function deliverTimeout(order, product) {
  if (order.notify_sent) return;
  await patchOrder(order.id, { notify_sent: 1 });
  const card = webNotify.buildTimeoutCard(order, product);
  webNotify.notifyBuyer(order.user_id, card).catch(() => {});
  webNotify.notifySaleToStaff(order, product).catch(() => {});
}

async function notifyBuyerFailKeepVps(order, ip, rdpPort, rdpPass) {
  const address = rdpPort && rdpPort !== 3389 ? `${ip}:${rdpPort}` : ip;
  const text = `⚠️ *Order RDP #${order.id}*\n\nVPS sudah dibuat (\`${address}\`) tetapi SSH belum siap untuk instalasi otomatis. ` +
    `Silakan REBUILD dari bot (menu VPS/RDP Saya). Password RDP: \`${rdpPass}\`.`;
  webNotify.notifyBuyer(order.user_id, text).catch(() => {});
}

// ---------------------------------------------------------------------------
// Baca order (scoped) + daftar.
// ---------------------------------------------------------------------------
async function getOrder({ orderId, token, session }) {
  const row = await getOrderRow(orderId);
  if (!row) return { ok: false, code: 404 };
  const authed = session && (session.isAdmin || (row.user_id != null && String(session.userId) === String(row.user_id)));
  const byToken = token && row.public_token && token === row.public_token;
  if (!authed && !byToken) return { ok: false, code: 403 };
  return { ok: true, view: toView(row) };
}

async function listMyOrders(userId) {
  const rows = await db.all('SELECT * FROM web_orders WHERE user_id = ? ORDER BY id DESC LIMIT 50', [userId]);
  return rows.map(toView);
}

async function listAllOrders(limit = 200) {
  const rows = await db.all('SELECT * FROM web_orders ORDER BY id DESC LIMIT ?', [limit]);
  return rows.map(o => ({ ...toView(o), telegramInput: o.telegram_input, apiId: o.api_id, productId: o.product_id, payRef: o.pay_ref }));
}

// ---------------------------------------------------------------------------
// Resume sweep saat server boot (tahan restart).
// ---------------------------------------------------------------------------
async function initStore() {
  try {
    // 1) awaiting_payment: pasang ulang poller / kedaluwarsakan.
    const awaiting = await db.all("SELECT * FROM web_orders WHERE status = 'awaiting_payment'");
    for (const o of awaiting) {
      if (o.expire_at && now() > o.expire_at) {
        await patchOrder(o.id, { status: 'expired', step: 'Pembayaran kedaluwarsa (saat server restart).', slot_reserved: 0 });
        await safeReleaseSlot(o.product_id, o.duration_days);
        try { await cancelPayment(o.pay_ref); } catch (_) {}
      } else {
        armPoller(o.id);
      }
    }

    // 2) order menggantung saat server mati.
    const stuck = await db.all("SELECT * FROM web_orders WHERE status IN ('paid','provisioning','installing')");
    for (const o of stuck) {
      if (!o.droplet_id) {
        // Belum sempat buat VPS -> aman dilanjut dari awal.
        console.log(`[webStore] resume provisioning order #${o.id} (belum ada droplet).`);
        runProvision(o.id).catch(e => console.error('[webStore] resume provision error:', e.message || e));
      } else {
        // VPS sudah ada tapi instalasi SSH tak bisa dilanjut -> tandai gagal, uang tetap (ada VPS).
        await patchOrder(o.id, {
          status: 'failed',
          step: 'Instalasi terputus (server restart)',
          error: 'Instalasi terputus saat server restart. VPS sudah dibuat — silakan rebuild dari bot (VPS/RDP Saya).',
          slot_reserved: 0
        });
        notifyBuyerFailKeepVps(o, o.ip || '-', o.rdp_port || 3389, o.rdp_password || '-');
      }
    }
    console.log(`[webStore] init: ${awaiting.length} order menunggu QRIS, ${stuck.length} order menggantung diproses.`);
  } catch (e) {
    console.error('[webStore] initStore error:', e.message || e);
  }
}

module.exports = {
  getCatalog,
  getOsList,
  resolveRegions,
  checkout,
  getOrder,
  listMyOrders,
  listAllOrders,
  initStore,
  // util untuk test
  normalizeDuration,
  durationLabel
};
