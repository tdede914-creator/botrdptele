// webNotify.js — notifikasi Telegram untuk WEB STORE.
// Proses web (`npm run web`) tidak membuat instance TelegramBot (polling:false),
// jadi kita kirim langsung via HTTP Bot API pakai axios — pola yang sama dengan
// webAuth.js (kirim kode login). Semua fungsi best-effort: gagal kirim TIDAK
// boleh menggagalkan order.

const axios = require('axios');

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;

function getChannelChatId() {
  const raw = process.env.ORDER_NOTIFY_CHAT_ID || process.env.NOTIFY_CHANNEL_ID || '';
  const v = String(raw).trim();
  return v ? v : null;
}

function getAdminChatId() {
  const raw = process.env.ADMIN_ID || '';
  const v = String(raw).trim();
  return v ? v : null;
}

function fmtPrice(n) {
  const num = Number(n || 0);
  return Number.isFinite(num) ? num.toLocaleString('id-ID') : '0';
}

/**
 * Kirim pesan ke satu chat_id (user / channel / grup).
 * @returns {Promise<{ok:boolean, error?:string}>}
 */
async function sendTo(chatId, text, opts = {}) {
  if (!BOT_TOKEN) return { ok: false, error: 'TELEGRAM_BOT_TOKEN belum diset' };
  if (!chatId) return { ok: false, error: 'chat_id kosong' };
  try {
    await axios.post(
      `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`,
      {
        chat_id: chatId,
        text,
        parse_mode: opts.parseMode || 'Markdown',
        disable_web_page_preview: true,
      },
      { timeout: 15000 }
    );
    return { ok: true };
  } catch (e) {
    const msg = e?.response?.data?.description || e?.message || String(e);
    console.error('[webNotify] gagal kirim ke', chatId, ':', msg);
    return { ok: false, error: msg };
  }
}

/**
 * Kirim ke pembeli (user_id Telegram numerik). Kalau input berupa @username
 * tidak bisa dikirim langsung (Bot API perlu chat_id numerik) -> di-skip aman.
 */
async function notifyBuyer(userId, text, opts = {}) {
  if (userId == null) return { ok: false, error: 'userId kosong' };
  const idStr = String(userId).trim();
  if (!/^\-?\d+$/.test(idStr)) {
    // @username / non-numerik: tidak bisa dikirim via Bot API tanpa chat_id.
    return { ok: false, error: 'chat_id non-numerik' };
  }
  return sendTo(idStr, text, opts);
}

async function notifyChannel(text, opts = {}) {
  const chatId = getChannelChatId();
  if (!chatId) return { ok: false, error: 'channel belum diset' };
  return sendTo(chatId, text, opts);
}

async function notifyAdmin(text, opts = {}) {
  const chatId = getAdminChatId();
  if (!chatId) return { ok: false, error: 'ADMIN_ID belum diset' };
  return sendTo(chatId, text, opts);
}

/**
 * Kartu kredensial RDP siap — dikirim ke pembeli, mirip kartu di bot.
 * order: baris web_orders (punya ip, rdp_port, rdp_password, os_name, dst).
 */
function buildCredentialCard(order, product) {
  const ip = order.ip || '-';
  const port = order.rdp_port || 3389;
  const address = port && port !== 3389 ? `${ip}:${port}` : ip;
  const spec = product ? `${product.ram || '-'}GB RAM / ${product.core || '-'} vCPU` : '-';
  const durationLabel = durationText(order.duration_days);
  const lines = [
    '✅ *RDP KAMU SUDAH SIAP!*',
    '',
    `🖥️ *IP / Address:* \`${address}\``,
    `👤 *Username:* \`Administrator\``,
    `🔑 *Password:* \`${order.rdp_password || '-'}\``,
    `🪟 *OS:* ${order.os_name || '-'}`,
    `📦 *Spesifikasi:* ${spec}`,
    `📍 *Region:* ${order.region || '-'}`,
    `⏳ *Durasi:* ${durationLabel}`,
    '',
    '_Buka Remote Desktop (mstsc) → masukkan IP/Address di atas → login dengan Administrator + password._',
  ];
  return lines.join('\n');
}

function buildTimeoutCard(order, product) {
  const ip = order.ip || '-';
  const port = order.rdp_port || 3389;
  const address = port && port !== 3389 ? `${ip}:${port}` : ip;
  const lines = [
    '⚠️ *RDP DIBUAT — VERIFIKASI PORT MELEBIHI WAKTU*',
    '',
    'Instalasi sudah dijalankan, tetapi bot belum sempat memverifikasi port RDP terbuka. Kredensial tetap kami kirim — coba beberapa menit lagi:',
    '',
    `🖥️ *IP / Address:* \`${address}\``,
    `👤 *Username:* \`Administrator\``,
    `🔑 *Password:* \`${order.rdp_password || '-'}\``,
    `🪟 *OS:* ${order.os_name || '-'}`,
    `📍 *Region:* ${order.region || '-'}`,
  ];
  return lines.join('\n');
}

function durationText(days) {
  const d = Number(days);
  if (d === 1) return 'Harian (1 hari)';
  if (d === 7) return 'Mingguan (7 hari)';
  if (d === 30) return 'Bulanan (30 hari)';
  return `${d} hari`;
}

/**
 * Ringkasan penjualan ke channel + admin (best-effort, tidak menunggu).
 */
async function notifySaleToStaff(order, product) {
  const spec = product ? `${product.ram || '-'}GB / ${product.core || '-'} vCPU` : '-';
  const text = [
    '✅ *ORDER RDP (WEB) BERHASIL*',
    `🌐 IP: \`${order.ip || '-'}\``,
    `👤 Buyer ID: \`${order.user_id || order.telegram_input || '-'}\``,
    `📦 Spek: ${spec}`,
    `📍 Region: ${order.region || '-'}`,
    `🪟 OS: ${order.os_name || '-'}`,
    `⏳ Durasi: ${durationText(order.duration_days)}`,
    `💳 Metode: ${(order.pay_method || '-').toUpperCase()}`,
    `💰 Harga: Rp ${fmtPrice(order.price)}`,
    `🧾 Order #${order.id}`,
  ].join('\n');
  // channel dulu, lalu admin (kalau channel tak diset admin tetap tahu)
  await notifyChannel(text);
  await notifyAdmin(text);
}

module.exports = {
  sendTo,
  notifyBuyer,
  notifyChannel,
  notifyAdmin,
  notifySaleToStaff,
  buildCredentialCard,
  buildTimeoutCard,
  durationText,
  fmtPrice,
};
