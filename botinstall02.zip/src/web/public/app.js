// ============================================================================
// RDP Store — frontend (vanilla JS, tanpa build step).
// Etalase publik (jual RDP seperti bot) + Dompet (top-up QRIS) + Pesanan/RDP
// Saya + alat Renter (lama) + panel Admin. Polling tahan-refresh via localStorage.
// ============================================================================
const $ = (id) => document.getElementById(id);
async function api(path, opts = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
    ...opts,
    body: opts.body ? JSON.stringify(opts.body) : undefined
  });
  const data = await res.json().catch(() => ({ ok: false, message: 'Bad response' }));
  return { status: res.status, ...data };
}

let me = null;              // { userId, isAdmin, isRenter, role, username, balance }
let curDuration = 30;
let co = null;              // konteks checkout
let orderTimer = null, topupTimer = null, installTimer = null, powerTimer = null;

// ---- Utils ----
function fmtIDR(n) { return 'Rp ' + Number(n || 0).toLocaleString('id-ID'); }
function durLabel(d) { d = Number(d); return d === 1 ? 'Harian' : d === 7 ? 'Mingguan' : d === 30 ? 'Bulanan' : (d + ' hari'); }
function numOrNull(v) { const n = Number(v); return (v === '' || v == null || isNaN(n)) ? null : n; }
function toast(msg, type = '') {
  const el = $('app-msg');
  el.textContent = msg;
  el.className = 'msg floating show ' + type;
  setTimeout(() => { el.className = 'msg floating ' + type; }, 3200);
}
function loginMsg(msg, type = '') { const el = $('login-msg'); el.textContent = msg; el.className = 'msg ' + type; }
function coMsg(msg, type = '') { const el = $('co-msg'); el.textContent = msg; el.className = 'msg ' + type; }
function openModal(id) { $(id).classList.remove('hidden'); }
function closeModal(id) {
  $(id).classList.add('hidden');
  if (id === 'order-modal' && orderTimer) { clearInterval(orderTimer); orderTimer = null; }
  if (id === 'topup-modal' && topupTimer) { clearInterval(topupTimer); topupTimer = null; }
}
function orderStatusBadge(s) {
  const map = {
    done: ['on', 'Selesai'], failed: ['off', 'Gagal'], expired: ['off', 'Kedaluwarsa'],
    awaiting_payment: ['wait', 'Menunggu bayar'], provisioning: ['wait', 'Diproses'], installing: ['wait', 'Install']
  };
  const [c, l] = map[s] || ['wait', s];
  return `<span class="badge ${c}">${l}</span>`;
}

// ---- Auth / identitas ----
async function refreshMe() {
  const r = await api('/api/me');
  me = r.ok ? r : null;
  renderAuthUI();
  return me;
}
function renderAuthUI() {
  const authed = !!me;
  document.querySelectorAll('.need-auth').forEach(e => e.classList.toggle('hidden', !authed));
  document.querySelectorAll('.need-renter').forEach(e => e.classList.toggle('hidden', !(me && (me.isRenter || me.isAdmin))));
  document.querySelectorAll('.need-admin').forEach(e => e.classList.toggle('hidden', !(me && me.isAdmin)));
  $('btn-login-nav').classList.toggle('hidden', authed);
  $('btn-logout').classList.toggle('hidden', !authed);
  if (authed) {
    const uname = me.username ? '@' + String(me.username).replace(/^@/, '') : ('ID ' + me.userId);
    const roleLabel = me.isAdmin ? '👑 Admin' : (me.isRenter ? '🛠️ Renter' : '🧑 User');
    $('user-badge').textContent = `${roleLabel} • ${uname}`;
  } else {
    $('user-badge').textContent = '';
  }
}

// ---- Router sederhana ----
function showView(name) {
  if (['orders', 'wallet'].includes(name) && !me) name = 'login';
  if (name === 'renter' && !(me && (me.isRenter || me.isAdmin))) name = me ? 'store' : 'login';
  if (name === 'admin' && !(me && me.isAdmin)) name = me ? 'store' : 'login';
  document.querySelectorAll('.view-panel').forEach(v => v.classList.remove('active'));
  const el = $('view-' + name);
  if (el) el.classList.add('active');
  document.querySelectorAll('.navbtn').forEach(x => x.classList.toggle('active', x.dataset.view === name));
  if (name === 'store') loadProducts();
  if (name === 'orders') { loadMyOrders(); loadMyVps(); }
  if (name === 'wallet') { loadBalance(); loadTopups(); }
  if (name === 'renter') { loadServers(); loadApis(); }
  if (name === 'admin') { loadAdminProducts(); loadAdminApiOptions(); }
}

document.querySelectorAll('.navbtn').forEach(b => b.onclick = () => showView(b.dataset.view));
$('btn-login-nav').onclick = () => showView('login');
$('brand-home').onclick = () => showView('store');
$('btn-logout').onclick = async () => { await api('/api/auth/logout', { method: 'POST' }); location.reload(); };

// Sub-tab (renter/admin)
document.querySelectorAll('.subtab').forEach(t => t.onclick = () => {
  const view = t.closest('.view-panel');
  view.querySelectorAll('.subtab').forEach(x => x.classList.remove('active'));
  view.querySelectorAll('.subpanel').forEach(p => p.classList.remove('active'));
  t.classList.add('active');
  $('sub-' + t.dataset.sub).classList.add('active');
  onSubOpen(t.dataset.sub);
});
function onSubOpen(sub) {
  if (sub === 'r-power') loadPowerApis();
  if (sub === 'r-install') loadInstallApis();
  if (sub === 'r-apis') loadApis();
  if (sub === 'a-products') { loadAdminProducts(); loadAdminApiOptions(); }
  if (sub === 'a-apis') loadAdminApis();
  if (sub === 'a-instances') loadAdminInstances();
  if (sub === 'a-orders') loadAdminOrders();
}

// Modal close (tombol X + klik backdrop)
document.querySelectorAll('.modal-close').forEach(b => b.onclick = () => closeModal(b.dataset.close));
document.querySelectorAll('.modal-overlay').forEach(ov => ov.addEventListener('click', e => { if (e.target === ov) closeModal(ov.id); }));

// ============================================================================
// ETALASE
// ============================================================================
document.querySelectorAll('#duration-seg button').forEach(b => b.onclick = () => {
  document.querySelectorAll('#duration-seg button').forEach(x => x.classList.remove('active'));
  b.classList.add('active');
  curDuration = Number(b.dataset.d);
  loadProducts();
});

async function loadProducts() {
  const box = $('prod-grid');
  box.innerHTML = '<div class="empty">Memuat paket...</div>';
  const r = await api('/api/store/products?duration=' + curDuration);
  if (!r.ok) { box.innerHTML = '<div class="empty">Gagal memuat katalog.</div>'; return; }
  if (!r.products || !r.products.length) { box.innerHTML = '<div class="empty">Belum ada paket untuk durasi ini.</div>'; return; }
  box.innerHTML = r.products.map(p => {
    const out = Number(p.slot) <= 0;
    return `<div class="prod-card">
      <div class="spec">${p.label}</div>
      <div class="price">${fmtIDR(p.price)}<span class="muted" style="font-size:.72rem"> / ${r.durationLabel}</span></div>
      <div class="stock ${out ? 'out' : ''}">Stok: ${p.slot}</div>
      <button class="btn primary small" style="width:100%;margin-top:8px" ${out ? 'disabled' : ''}
        onclick="openCheckout(${p.ram},${p.core},${curDuration},${p.price})">${out ? 'Habis' : 'Pesan'}</button>
    </div>`;
  }).join('');
}

window.openCheckout = async (ram, core, duration, price) => {
  co = { ram, core, duration, price, productId: null };
  $('co-spec').textContent = `${ram}GB RAM • ${core} vCPU • ${durLabel(duration)}`;
  $('co-total').innerHTML = `Total: <span>${fmtIDR(price)}</span>`;
  coMsg('');
  $('co-region').innerHTML = '<option>Memuat region...</option>';
  $('co-os').innerHTML = '';
  $('co-tele').value = '';
  const saldoWrap = $('co-pay-saldo-wrap');
  const teleWrap = $('co-tele-wrap');
  document.querySelector('input[name="pay"][value="qris"]').checked = true;
  if (me) {
    saldoWrap.classList.remove('hidden');
    $('co-saldo').textContent = fmtIDR(me.balance);
    teleWrap.classList.add('hidden');
  } else {
    saldoWrap.classList.add('hidden');
    teleWrap.classList.remove('hidden');
  }
  openModal('co-modal');
  loadCheckoutOs();
  loadCheckoutRegions();
};

async function loadCheckoutOs() {
  const r = await api('/api/store/os');
  const sel = $('co-os');
  if (r.ok && r.os) sel.innerHTML = r.os.map(o => `<option value="${o.index}">${o.name}</option>`).join('');
}
async function loadCheckoutRegions() {
  const sel = $('co-region');
  const r = await api(`/api/store/regions?ram=${co.ram}&core=${co.core}&duration=${co.duration}`);
  if (!r.ok) {
    sel.innerHTML = '<option value="">Gagal / stok habis</option>';
    coMsg(r.message || 'Gagal memuat region.', 'error');
    return;
  }
  co.productId = r.productId;
  if (r.price != null) { co.price = r.price; $('co-total').innerHTML = `Total: <span>${fmtIDR(r.price)}</span>`; }
  sel.innerHTML = (r.regions || []).map(rg => `<option value="${rg.slug}">${rg.name}</option>`).join('') || '<option value="">Tidak ada region</option>';
}

$('btn-checkout').onclick = async () => {
  if (!co) return;
  const payMethod = document.querySelector('input[name="pay"]:checked').value;
  const region = $('co-region').value;
  const osIndex = $('co-os').value;
  if (!region) return coMsg('Pilih region dulu.', 'error');
  if (osIndex === '') return coMsg('Pilih OS dulu.', 'error');
  const body = {
    productId: co.productId, ram: co.ram, core: co.core, duration: co.duration,
    region, osIndex: Number(osIndex), payMethod
  };
  if (!me) {
    if (payMethod === 'saldo') return coMsg('Bayar via saldo harus login dulu.', 'error');
    const tele = $('co-tele').value.trim();
    if (!/^\d{5,}$/.test(tele.replace(/[^\d]/g, ''))) return coMsg('Isi ID Telegram numerik (dari @userinfobot).', 'error');
    body.telegram = tele;
  }
  const btn = $('btn-checkout'); btn.disabled = true; coMsg('Memproses...');
  const r = await api('/api/store/checkout', { method: 'POST', body });
  btn.disabled = false;
  if (!r.ok) return coMsg('❌ ' + r.message, 'error');
  closeModal('co-modal');
  saveActiveOrder(r.orderId, r.publicToken);
  openOrder(r.orderId, r.publicToken);
  if (me) refreshMe();
};

// ---- Order polling (tahan refresh) ----
function saveActiveOrder(id, token) { try { localStorage.setItem('activeOrder', JSON.stringify({ id, token })); } catch (_) {} }
function clearActiveOrder() { try { localStorage.removeItem('activeOrder'); } catch (_) {} }

window.openOrder = (id, token) => {
  openModal('order-modal');
  if (orderTimer) { clearInterval(orderTimer); orderTimer = null; }
  const tick = async () => {
    const q = token ? ('?token=' + encodeURIComponent(token)) : '';
    const r = await api(`/api/store/order/${id}${q}`);
    if (!r.ok) { $('order-body').innerHTML = `<p class="msg error">${r.message || 'Gagal memuat order.'}</p>`; if (orderTimer) { clearInterval(orderTimer); orderTimer = null; } return; }
    renderOrder(r.order);
  };
  tick();
  orderTimer = setInterval(tick, 6000);
};

function renderOrder(o) {
  const body = $('order-body');
  const terminal = ['done', 'failed', 'expired'].includes(o.status);
  if (terminal && orderTimer) { clearInterval(orderTimer); orderTimer = null; }
  if (o.status === 'awaiting_payment') {
    body.innerHTML =
      `<p class="muted">Scan QRIS untuk membayar <b>${fmtIDR(o.price)}</b>.</p>
       ${o.qrImage ? `<div class="qr-box"><img src="${o.qrImage}" alt="QRIS"/></div>` : ''}
       <div class="step"><span class="spinner"></span> Menunggu pembayaran...</div>
       <p class="hint">Aman di-refresh — pembayaran & instalasi tetap berjalan di server.</p>`;
  } else if (o.status === 'done') {
    clearActiveOrder();
    body.innerHTML =
      `<div class="step">✅ <strong>RDP siap!</strong></div>
       <div class="cred">
         <div><b>Address:</b> <code>${o.address || o.ip || '-'}</code></div>
         <div><b>Username:</b> <code>${o.username || 'Administrator'}</code></div>
         <div><b>Password:</b> <code>${o.rdpPassword || '(cek Telegram)'}</code></div>
         <div><b>OS:</b> ${o.osName || '-'}</div>
         <div><b>Durasi:</b> ${o.durationLabel}</div>
       </div>
       <p class="hint">Detail juga dikirim ke Telegram.</p>`;
  } else if (o.status === 'failed') {
    clearActiveOrder();
    body.innerHTML =
      `<div class="step">❌ <strong>Gagal:</strong> ${o.error || 'terjadi kesalahan'}</div>
       <p class="hint">${o.payMethod === 'saldo' ? 'Saldo dikembalikan jika kegagalan terjadi sebelum VPS dibuat.' : 'Jika QRIS sudah terbayar, dana dikompensasi ke saldo.'}</p>`;
  } else if (o.status === 'expired') {
    clearActiveOrder();
    body.innerHTML = `<div class="step">⌛ Pembayaran kedaluwarsa. Silakan pesan ulang.</div>`;
  } else {
    body.innerHTML =
      `<div class="step"><span class="spinner"></span> ${o.step || o.status}</div>
       ${o.ip ? `<div class="item-sub">IP: <code>${o.ip}</code></div>` : ''}
       <p class="hint">Instalasi berjalan di server (±30-40 menit). Halaman aman ditutup/di-refresh.</p>`;
  }
}

// ============================================================================
// PESANAN & VPS SAYA
// ============================================================================
async function loadMyOrders() {
  const box = $('orders-list');
  const r = await api('/api/store/my-orders');
  if (!r.ok || !r.orders || !r.orders.length) { box.innerHTML = '<div class="empty">Belum ada pesanan.</div>'; return; }
  box.innerHTML = r.orders.map(o =>
    `<div class="item">
      <div class="item-info">
        <div class="item-title">Order #${o.id} ${orderStatusBadge(o.status)}</div>
        <div class="item-sub">${o.durationLabel} • ${fmtIDR(o.price)} • ${(o.payMethod || '').toUpperCase()} • ${o.region || '-'}</div>
      </div>
      <div class="item-actions"><button class="btn ghost small" onclick="openOrder(${o.id})">Lihat</button></div>
    </div>`
  ).join('');
}

async function loadMyVps() {
  const box = $('my-vps-list');
  const r = await api('/api/store/my-vps');
  if (!r.ok || !r.vps || !r.vps.length) { box.innerHTML = '<div class="empty">Belum ada VPS/RDP.</div>'; return; }
  box.innerHTML = r.vps.map(x => {
    const isRdp = (x.productType === 'rdp') || String(x.image || '').startsWith('rdp:');
    const addr = isRdp && x.ip ? `${x.ip}:${x.rdpPort}` : (x.ip || '-');
    return `<div class="item">
      <div class="item-info">
        <div class="item-title"><span class="badge ${isRdp ? 'rdp' : 'vps'}">${isRdp ? 'RDP' : 'VPS'}</span> ${addr}</div>
        <div class="item-sub">${x.sizeSlug || '-'} • ${x.region || '-'}</div>
      </div>
      <div class="item-actions">
        <button class="btn on small" onclick="myVpsPower(${x.id},'on')">ON</button>
        <button class="btn off small" onclick="myVpsPower(${x.id},'off')">OFF</button>
      </div>
    </div>`;
  }).join('');
}
window.myVpsPower = async (id, action) => {
  toast('Mengirim ' + action.toUpperCase() + '...');
  const r = await api(`/api/store/vps/${id}/power`, { method: 'POST', body: { action } });
  toast(r.ok ? `✅ ${action.toUpperCase()} terkirim` : ('❌ ' + r.message), r.ok ? 'success' : 'error');
};

// ============================================================================
// DOMPET
// ============================================================================
async function loadBalance() {
  const r = await api('/api/wallet/balance');
  $('wallet-balance').textContent = fmtIDR(r.ok ? r.balance : 0);
}
$('btn-topup').onclick = async () => {
  const amount = Number($('topup-amount').value);
  if (!amount || amount < 1000) return toast('Minimal top-up Rp 1.000', 'error');
  const btn = $('btn-topup'); btn.disabled = true;
  const r = await api('/api/wallet/topup', { method: 'POST', body: { amount } });
  btn.disabled = false;
  if (!r.ok) return toast('❌ ' + r.message, 'error');
  $('topup-amount').value = '';
  saveActiveTopup(r.topupId);
  openTopup(r.topupId);
};
async function loadTopups() {
  const box = $('topups-list');
  const r = await api('/api/wallet/my-topups');
  if (!r.ok || !r.topups || !r.topups.length) { box.innerHTML = '<div class="empty">Belum ada top-up.</div>'; return; }
  box.innerHTML = r.topups.map(t =>
    `<div class="item">
      <div class="item-info">
        <div class="item-title">${fmtIDR(t.amount)} ${orderStatusBadge(t.status)}</div>
        <div class="item-sub">#${t.id} • ${new Date((t.createdAt || 0) * 1000).toLocaleString('id-ID')}</div>
      </div>
      <div class="item-actions">${t.status === 'awaiting_payment' ? `<button class="btn ghost small" onclick="openTopup(${t.id})">Bayar</button>` : ''}</div>
    </div>`
  ).join('');
}

function saveActiveTopup(id) { try { localStorage.setItem('activeTopup', JSON.stringify({ id })); } catch (_) {} }
function clearActiveTopup() { try { localStorage.removeItem('activeTopup'); } catch (_) {} }

window.openTopup = (id) => {
  openModal('topup-modal');
  if (topupTimer) { clearInterval(topupTimer); topupTimer = null; }
  const tick = async () => {
    const r = await api('/api/wallet/topup/' + id);
    if (!r.ok) { $('topup-body').innerHTML = `<p class="msg error">${r.message || 'Gagal.'}</p>`; if (topupTimer) { clearInterval(topupTimer); topupTimer = null; } return; }
    const t = r.topup;
    if (t.status === 'done') {
      if (topupTimer) { clearInterval(topupTimer); topupTimer = null; }
      clearActiveTopup();
      $('topup-body').innerHTML = `<div class="step">✅ <strong>Top-up berhasil!</strong> Saldo +${fmtIDR(t.amount)}.</div>`;
      loadBalance(); loadTopups(); refreshMe();
    } else if (t.status === 'expired') {
      if (topupTimer) { clearInterval(topupTimer); topupTimer = null; }
      clearActiveTopup();
      $('topup-body').innerHTML = `<div class="step">⌛ QRIS kedaluwarsa.</div>`;
    } else {
      $('topup-body').innerHTML =
        `<p class="muted">Scan QRIS untuk top-up <b>${fmtIDR(t.amount)}</b>.</p>
         ${t.qrImage ? `<div class="qr-box"><img src="${t.qrImage}" alt="QRIS"/></div>` : ''}
         <div class="step"><span class="spinner"></span> Menunggu pembayaran...</div>
         <p class="hint">Aman di-refresh.</p>`;
    }
  };
  tick();
  topupTimer = setInterval(tick, 6000);
};

// ============================================================================
// LOGIN
// ============================================================================
let loginUserId = null;
$('btn-request-code').onclick = async () => {
  const identifier = $('identifier').value.trim();
  if (!identifier) return loginMsg('Isi username / user ID dulu.', 'error');
  loginMsg('Mengirim kode...');
  const r = await api('/api/auth/request-code', { method: 'POST', body: { identifier } });
  if (!r.ok) return loginMsg(r.message, 'error');
  loginUserId = r.userId;
  $('step-identifier').classList.add('hidden');
  $('step-code').classList.remove('hidden');
  loginMsg(r.message, 'success');
};
$('btn-back-identifier').onclick = () => {
  $('step-code').classList.add('hidden');
  $('step-identifier').classList.remove('hidden');
  loginMsg('');
};
$('btn-verify-code').onclick = async () => {
  const code = $('code').value.trim();
  if (!code) return loginMsg('Masukkan kode.', 'error');
  loginMsg('Memverifikasi...');
  const r = await api('/api/auth/verify-code', { method: 'POST', body: { userId: loginUserId, code } });
  if (!r.ok) return loginMsg(r.message, 'error');
  await refreshMe();
  loginMsg('');
  $('step-code').classList.add('hidden');
  $('step-identifier').classList.remove('hidden');
  $('identifier').value = ''; $('code').value = '';
  showView('store');
  toast('✅ Login berhasil', 'success');
  resumeActive();
};

// ============================================================================
// RENTER (alat lama: API pribadi + install + power)
// ============================================================================
function serverItem(x, actionsHtml) {
  const type = x.type === 'rdp' ? 'RDP' : 'VPS';
  const server = x.type === 'rdp' && x.ip ? `${x.ip}:${x.rdp_port}` : (x.ip || '-');
  return `<div class="item">
    <div class="item-info">
      <div class="item-title"><span class="badge ${x.type}">${type}</span> ${server}</div>
      <div class="item-sub">API#${x.api_id ?? '-'} • ${x.size_slug || '-'} • ${x.region || '-'}</div>
    </div>
    <div class="item-actions">${actionsHtml || ''}</div>
  </div>`;
}
async function loadServers() {
  const r = await api('/api/instances');
  const box = $('servers-list');
  if (!r.ok || !r.instances.length) { box.innerHTML = '<div class="empty">Belum ada VPS/RDP.</div>'; return; }
  box.innerHTML = r.instances.map(x => serverItem(x)).join('');
}
async function loadPowerApis() {
  const r = await api('/api/apis');
  const sel = $('power-api-select');
  if (!r.ok || !r.apis.length) {
    sel.innerHTML = '<option value="">Belum ada API</option>';
    $('power-list').innerHTML = '<div class="empty">Tambahkan API dulu di tab API Cloud.</div>';
    return;
  }
  sel.innerHTML = r.apis.map(a => `<option value="${a.id}">${a.provider || 'DigitalOcean'} API#${a.id} • ${a.email || '-'}</option>`).join('');
  sel.onchange = () => loadPowerInstances(sel.value);
  loadPowerInstances(sel.value);
}
async function loadPowerInstances(apiId) {
  if (!apiId) return;
  const statusEl = $('power-status');
  statusEl.textContent = 'Cek status akun cloud...';
  statusEl.className = 'status-line';
  const st = await api(`/api/apis/${apiId}/status`);
  if (st.ok && st.status.ok) {
    statusEl.textContent = `Status akun cloud: 🟢 ${st.status.label} (${st.status.email})`;
    statusEl.className = 'status-line ok';
  } else {
    const reason = st.ok ? st.status.reason : st.message;
    statusEl.textContent = `Status akun cloud: ⚠️ Bermasalah — ${reason}`;
    statusEl.className = 'status-line bad';
  }
  const r = await api('/api/instances?apiId=' + encodeURIComponent(apiId));
  const box = $('power-list');
  if (!r.ok || !r.instances.length) { box.innerHTML = '<div class="empty">Tidak ada server untuk API ini.</div>'; return; }
  box.innerHTML = r.instances.map(x => serverItem(x,
    `<button class="btn on small" onclick="renterPower(${x.id},'on')">ON</button>
     <button class="btn off small" onclick="renterPower(${x.id},'off')">OFF</button>`
  )).join('');
}
window.renterPower = async (id, action) => {
  toast('Mengirim ' + action.toUpperCase() + '...');
  const r = await api(`/api/instances/${id}/power`, { method: 'POST', body: { action } });
  toast(r.ok ? `✅ ${action.toUpperCase()} terkirim` : ('❌ ' + r.message), r.ok ? 'success' : 'error');
};
async function loadApis() {
  const r = await api('/api/apis');
  const box = $('apis-list');
  if (!r.ok || !r.apis.length) { box.innerHTML = '<div class="empty">Belum ada API cloud.</div>'; return; }
  box.innerHTML = r.apis.map(a => `<div class="item">
    <div class="item-info">
      <div class="item-title">${a.provider || 'DigitalOcean'} API#${a.id}</div>
      <div class="item-sub">${a.email || '-'} • ${Number(a.status) === 1 ? 'Aktif' : 'Nonaktif'}</div>
    </div>
    <div class="item-actions"><button class="btn danger small" onclick="deleteApi(${a.id})">Hapus</button></div>
  </div>`).join('');
}
$('btn-add-api').onclick = async () => {
  const token = $('add-api-token').value.trim();
  const provider = $('add-api-provider').value;
  if (!token) return toast('Isi token dulu.', 'error');
  const r = await api('/api/apis', { method: 'POST', body: { token, provider } });
  if (!r.ok) return toast('❌ ' + r.message, 'error');
  $('add-api-token').value = '';
  toast('✅ API ditambahkan', 'success');
  loadApis();
};
window.deleteApi = async (id) => {
  if (!confirm('Hapus API#' + id + '?')) return;
  const r = await api('/api/apis/' + id, { method: 'DELETE' });
  toast(r.ok ? '✅ API dihapus' : ('❌ ' + r.message), r.ok ? 'success' : 'error');
  loadApis();
};
async function loadInstallApis() {
  const r = await api('/api/apis');
  const sel = $('install-api');
  if (!r.ok || !r.apis.length) { sel.innerHTML = '<option value="">Belum ada API</option>'; return; }
  sel.innerHTML = r.apis.map(a => `<option value="${a.id}">${a.provider || 'DigitalOcean'} API#${a.id} • ${a.email || '-'}</option>`).join('');
  sel.onchange = loadRegions;
  await loadWindows();
  await loadRegions();
}
async function loadWindows() {
  const r = await api('/api/windows');
  const sel = $('install-windows');
  if (r.ok) sel.innerHTML = r.windows.map(w => `<option value="${w.index}">${w.name}</option>`).join('');
}
async function loadRegions() {
  const apiId = $('install-api').value;
  if (!apiId) return;
  const sel = $('install-region');
  sel.innerHTML = '<option>Memuat...</option>';
  const r = await api('/api/regions?apiId=' + apiId);
  if (!r.ok || !r.regions || !r.regions.length) { sel.innerHTML = '<option value="">Gagal / kosong</option>'; return; }
  sel.innerHTML = r.regions.map(rg => {
    const slug = rg.slug || rg.id || rg;
    return `<option value="${slug}">${rg.name || slug}</option>`;
  }).join('');
  sel.onchange = loadSizes;
  await loadSizes();
}
async function loadSizes() {
  const apiId = $('install-api').value;
  const region = $('install-region').value;
  if (!apiId || !region) return;
  const sel = $('install-size');
  sel.innerHTML = '<option>Memuat...</option>';
  const r = await api(`/api/sizes?apiId=${apiId}&region=${encodeURIComponent(region)}`);
  if (!r.ok || !r.sizes || !r.sizes.length) { sel.innerHTML = '<option value="">Gagal / kosong</option>'; return; }
  sel.innerHTML = r.sizes.map(s => {
    const slug = s.slug || s.id || s;
    return `<option value="${slug}">${s.label || s.description || slug}</option>`;
  }).join('');
}
$('install-form').onsubmit = async (e) => {
  e.preventDefault();
  const body = {
    apiId: $('install-api').value, region: $('install-region').value,
    sizeSlug: $('install-size').value, winIndex: $('install-windows').value
  };
  if (!body.apiId || !body.region || !body.sizeSlug) return toast('Lengkapi form dulu.', 'error');
  const r = await api('/api/install-rdp', { method: 'POST', body });
  if (!r.ok) return toast('❌ ' + r.message, 'error');
  pollInstall(r.jobId);
};
function pollInstall(jobId) {
  const box = $('install-progress');
  box.classList.remove('hidden');
  if (installTimer) clearInterval(installTimer);
  try { localStorage.setItem('activeJob', jobId); } catch (_) {}
  const render = (j) => {
    if (j.status === 'done') {
      box.innerHTML =
        `<div class="step">✅ <strong>RDP siap!</strong></div>
         <div class="cred">
           <div><b>Address:</b> <code>${j.ip}:${j.rdpPort}</code></div>
           <div><b>Username:</b> <code>Administrator</code></div>
           <div><b>Password:</b> <code>${j.rdpPassword || '(lihat di VPS/RDP Saya)'}</code></div>
         </div>`;
      clearInterval(installTimer); installTimer = null;
      try { localStorage.removeItem('activeJob'); } catch (_) {}
      loadServers();
    } else if (j.status === 'failed') {
      box.innerHTML = `<div class="step">❌ <strong>Gagal:</strong> ${j.error || 'Unknown'}</div>`;
      clearInterval(installTimer); installTimer = null;
      try { localStorage.removeItem('activeJob'); } catch (_) {}
    } else {
      box.innerHTML = `<div class="step"><span class="spinner"></span> ${j.step || j.status}</div>
        ${j.ip ? `<div class="item-sub">IP: <code>${j.ip}</code></div>` : ''}`;
    }
  };
  const tick = async () => { const r = await api('/api/install-rdp/' + jobId); if (r.ok) render(r); };
  tick();
  installTimer = setInterval(tick, 5000);
}

// ============================================================================
// ADMIN
// ============================================================================
async function loadAdminProducts() {
  const box = $('admin-products');
  const r = await api('/api/admin/products');
  if (!r.ok) { box.innerHTML = '<div class="empty">Gagal memuat.</div>'; return; }
  if (!r.products.length) { box.innerHTML = '<div class="empty">Belum ada produk.</div>'; return; }
  box.innerHTML = r.products.map(adminProductItem).join('');
}
function adminProductItem(p) {
  const on = Number(p.status) === 1;
  return `<div class="item" style="flex-direction:column;align-items:stretch">
    <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap">
      <div class="item-info">
        <div class="item-title">#${p.id} • ${p.ram}GB / ${p.core} vCPU <span class="badge ${on ? 'on' : 'off'}">${on ? 'Aktif' : 'Nonaktif'}</span></div>
        <div class="item-sub">${p.size_slug || '-'} • API#${p.api_id} ${p.api_email ? ('(' + p.api_email + ')') : ''} ${Number(p.api_status) !== 1 ? '⚠️ API nonaktif' : ''}</div>
      </div>
      <div class="item-actions">
        <button class="btn ${on ? 'off' : 'on'} small" onclick="toggleProduct(${p.id}, ${on ? 0 : 1})">${on ? 'Matikan' : 'Aktifkan'}</button>
        <button class="btn danger small" onclick="delProduct(${p.id})">Hapus</button>
      </div>
    </div>
    <div class="grid2" style="margin-top:10px">
      <div>
        <label>Harga H / M / B</label>
        <div style="display:flex;gap:6px">
          <input id="pp-d-${p.id}" type="number" value="${p.price_daily ?? ''}" placeholder="harian"/>
          <input id="pp-w-${p.id}" type="number" value="${p.price_weekly ?? ''}" placeholder="mingguan"/>
          <input id="pp-m-${p.id}" type="number" value="${p.price ?? ''}" placeholder="bulanan"/>
        </div>
        <button class="btn ghost small" style="margin-top:6px" onclick="saveProdPrice(${p.id})">💾 Simpan Harga</button>
      </div>
      <div>
        <label>Slot H / M / B</label>
        <div style="display:flex;gap:6px">
          <input id="ps-d-${p.id}" type="number" value="${p.slot_daily ?? 0}" placeholder="harian"/>
          <input id="ps-w-${p.id}" type="number" value="${p.slot_weekly ?? 0}" placeholder="mingguan"/>
          <input id="ps-m-${p.id}" type="number" value="${p.slot_monthly ?? 0}" placeholder="bulanan"/>
        </div>
        <button class="btn ghost small" style="margin-top:6px" onclick="saveProdSlots(${p.id})">💾 Simpan Slot</button>
      </div>
    </div>
  </div>`;
}
window.saveProdPrice = async (id) => {
  const body = { daily: numOrNull($('pp-d-' + id).value), weekly: numOrNull($('pp-w-' + id).value), monthly: numOrNull($('pp-m-' + id).value) };
  const r = await api(`/api/admin/products/${id}/price`, { method: 'POST', body });
  toast(r.ok ? '✅ Harga disimpan' : ('❌ ' + r.message), r.ok ? 'success' : 'error');
};
window.saveProdSlots = async (id) => {
  const body = { daily: numOrNull($('ps-d-' + id).value), weekly: numOrNull($('ps-w-' + id).value), monthly: numOrNull($('ps-m-' + id).value) };
  const r = await api(`/api/admin/products/${id}/slots`, { method: 'POST', body });
  toast(r.ok ? '✅ Slot disimpan' : ('❌ ' + r.message), r.ok ? 'success' : 'error');
  if (r.ok) loadAdminProducts();
};
window.toggleProduct = async (id, status) => {
  const r = await api(`/api/admin/products/${id}/status`, { method: 'POST', body: { status } });
  toast(r.ok ? '✅ Status diubah' : ('❌ ' + r.message), r.ok ? 'success' : 'error');
  if (r.ok) loadAdminProducts();
};
window.delProduct = async (id) => {
  if (!confirm('Hapus produk #' + id + '?')) return;
  const r = await api('/api/admin/products/' + id, { method: 'DELETE' });
  toast(r.ok ? '✅ Produk dihapus' : ('❌ ' + r.message), r.ok ? 'success' : 'error');
  if (r.ok) loadAdminProducts();
};
async function loadAdminApiOptions() {
  const r = await api('/api/admin/apis');
  const sel = $('np-api');
  if (r.ok && r.apis && r.apis.length) sel.innerHTML = r.apis.map(a => `<option value="${a.id}">API#${a.id} • ${a.provider} • ${a.email || '-'}</option>`).join('');
  else sel.innerHTML = '<option value="">Belum ada API pool</option>';
}
$('btn-add-product').onclick = async () => {
  const body = {
    apiId: $('np-api').value, sizeSlug: $('np-size').value.trim(),
    ram: $('np-ram').value, core: $('np-core').value,
    priceDaily: numOrNull($('np-price-d').value), slotDaily: $('np-slot-d').value || 0,
    priceWeekly: numOrNull($('np-price-w').value), slotWeekly: $('np-slot-w').value || 0,
    priceMonthly: numOrNull($('np-price-m').value), slotMonthly: $('np-slot-m').value || 0
  };
  if (!body.apiId || !body.sizeSlug) return toast('API & size slug wajib.', 'error');
  const r = await api('/api/admin/products', { method: 'POST', body });
  toast(r.ok ? '✅ Produk ditambahkan' : ('❌ ' + r.message), r.ok ? 'success' : 'error');
  if (r.ok) {
    ['np-size', 'np-ram', 'np-core', 'np-price-d', 'np-slot-d', 'np-price-w', 'np-slot-w', 'np-price-m', 'np-slot-m'].forEach(id => $(id).value = '');
    loadAdminProducts();
  }
};
async function loadAdminApis() {
  const box = $('admin-apis');
  const r = await api('/api/admin/apis');
  if (!r.ok || !r.apis.length) { box.innerHTML = '<div class="empty">Belum ada API di pool.</div>'; return; }
  box.innerHTML = r.apis.map(a => {
    const on = Number(a.status) === 1;
    return `<div class="item">
      <div class="item-info">
        <div class="item-title">API#${a.id} • ${a.provider} <span class="badge ${on ? 'on' : 'off'}">${on ? 'Aktif' : 'Nonaktif'}</span></div>
        <div class="item-sub">${a.email || '-'}</div>
      </div>
      <div class="item-actions">
        <button class="btn ghost small" onclick="checkAdminApi(${a.id})">Cek Status</button>
        ${on ? `<button class="btn off small" onclick="disableAdminApi(${a.id})">Nonaktifkan</button>` : ''}
        <button class="btn danger small" onclick="delAdminApi(${a.id})">Hapus</button>
      </div>
    </div>`;
  }).join('');
}
window.checkAdminApi = async (id) => {
  toast('Cek status API#' + id + '...');
  const r = await api(`/api/admin/apis/${id}/status`);
  if (r.ok && r.status.ok) toast(`🟢 API#${id} ${r.status.label} (${r.status.email})`, 'success');
  else toast(`⚠️ API#${id} ${r.ok ? r.status.reason : r.message}`, 'error');
};
window.disableAdminApi = async (id) => {
  if (!confirm('Nonaktifkan API#' + id + '? Produk dari API ini ikut dimatikan.')) return;
  const r = await api(`/api/admin/apis/${id}/disable`, { method: 'POST' });
  toast(r.ok ? '✅ API dinonaktifkan' : ('❌ ' + r.message), r.ok ? 'success' : 'error');
  if (r.ok) loadAdminApis();
};
window.delAdminApi = async (id) => {
  if (!confirm('HAPUS PERMANEN API#' + id + '? Semua produk & instance dari API ini akan dihapus dari DB.')) return;
  const r = await api('/api/admin/apis/' + id, { method: 'DELETE' });
  toast(r.ok ? '✅ API dihapus' : ('❌ ' + r.message), r.ok ? 'success' : 'error');
  if (r.ok) loadAdminApis();
};
$('btn-admin-add-api').onclick = async () => {
  const token = $('admin-add-api-token').value.trim();
  if (!token) return toast('Isi token dulu.', 'error');
  const r = await api('/api/admin/apis', { method: 'POST', body: { token } });
  if (!r.ok) return toast('❌ ' + r.message, 'error');
  $('admin-add-api-token').value = '';
  toast('✅ API ditambahkan ke pool', 'success');
  loadAdminApis();
};
async function loadAdminInstances() {
  const box = $('admin-instances');
  const r = await api('/api/admin/instances');
  if (!r.ok || !r.instances.length) { box.innerHTML = '<div class="empty">Belum ada instance.</div>'; return; }
  box.innerHTML = r.instances.map(x => {
    const isRdp = (x.product_type === 'rdp') || String(x.image || '').startsWith('rdp:');
    const addr = isRdp && x.ip ? `${x.ip}:${x.rdp_port || 4443}` : (x.ip || '-');
    const buyer = x.buyer_username ? '@' + String(x.buyer_username).replace(/^@/, '') : ('ID ' + (x.user_id ?? '-'));
    const canPower = !!x.droplet_id;
    const src = x.source === 'renter' ? 'renter' : 'normal';
    return `<div class="item">
      <div class="item-info">
        <div class="item-title"><span class="badge ${isRdp ? 'rdp' : 'vps'}">${isRdp ? 'RDP' : 'VPS'}</span> ${addr} <span class="muted" style="font-size:.72rem">${x.api_scope || ''}</span></div>
        <div class="item-sub">Pembeli: ${buyer} • API#${x.api_id ?? '-'} ${x.api_email ? ('(' + x.api_email + ')') : ''} • ${x.size_slug || '-'} • ${x.region || '-'}</div>
      </div>
      <div class="item-actions">
        ${canPower
          ? `<button class="btn on small" onclick="adminPower(${x.id},'on','${src}')">ON</button>
             <button class="btn off small" onclick="adminPower(${x.id},'off','${src}')">OFF</button>`
          : '<span class="muted" style="font-size:.75rem">no droplet</span>'}
      </div>
    </div>`;
  }).join('');
}
window.adminPower = async (id, action, source) => {
  toast('Mengirim ' + action.toUpperCase() + '...');
  const r = await api(`/api/admin/instances/${id}/power`, { method: 'POST', body: { action, source } });
  toast(r.ok ? `✅ ${action.toUpperCase()} terkirim` : ('❌ ' + r.message), r.ok ? 'success' : 'error');
};
async function loadAdminOrders() {
  const box = $('admin-orders');
  const r = await api('/api/admin/orders');
  if (!r.ok || !r.orders.length) { box.innerHTML = '<div class="empty">Belum ada order web.</div>'; return; }
  box.innerHTML = r.orders.map(o =>
    `<div class="item">
      <div class="item-info">
        <div class="item-title">Order #${o.id} ${orderStatusBadge(o.status)}</div>
        <div class="item-sub">Pembeli: ${o.userId ? ('ID ' + o.userId) : (o.telegramInput || '-')} • ${o.durationLabel} • ${fmtIDR(o.price)} • ${(o.payMethod || '').toUpperCase()} • ${o.region || '-'} ${o.address ? ('• ' + o.address) : ''}</div>
      </div>
    </div>`
  ).join('');
}

// ============================================================================
// BOOT + resume (tahan refresh)
// ============================================================================
function resumeActive() {
  try {
    const ao = JSON.parse(localStorage.getItem('activeOrder') || 'null');
    if (ao && ao.id) openOrder(ao.id, ao.token);
  } catch (_) {}
  if (me) {
    try {
      const at = JSON.parse(localStorage.getItem('activeTopup') || 'null');
      if (at && at.id) openTopup(at.id);
    } catch (_) {}
    if (me.isRenter || me.isAdmin) resumeInstall();
  }
}
async function resumeInstall() {
  try {
    const r = await api('/api/install-rdp/active');
    if (r.ok && r.active) { pollInstall(r.jobId); return; }
  } catch (_) {}
  let jid = null;
  try { jid = localStorage.getItem('activeJob'); } catch (_) {}
  if (jid) pollInstall(jid);
}

(async function boot() {
  await refreshMe();
  showView('store');
  resumeActive();
})();
