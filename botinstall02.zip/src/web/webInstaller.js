// ============================================================================
// webInstaller.js — Install RDP dari sisi WEBSITE, lepas dari Telegram.
// Reuse building block yang sama persis dengan bot (createDroplet, waitPublicIp,
// installDedicatedRDP, linodeAutoDirectDisk, saveInstance) agar hasil identik,
// termasuk fix Linode (Direct Disk adaptif). Tidak ada logika produk digital.
//
// Progres install disimpan in-memory + dicerminkan ke DB via saveInstance,
// supaya halaman web bisa polling status tanpa perlu koneksi Telegram.
// ============================================================================

const crypto = require('crypto');
const net = require('net');
const renterManager = require('../utils/renterManager');
const webNotify = require('./webNotify');
const {
  createDroplet, waitPublicIp, deleteDroplet,
  isLinodeToken, isAwsToken, isUpCloudToken,
  providerName, linodeAutoDirectDisk, rdpPortForToken
} = require('../utils/doApi');
const { installDedicatedRDP } = require('../utils/dedicatedRdpInstaller');
const RDPMonitor = require('../utils/rdpMonitor');
const { RDP_MONITOR_TIMEOUT_MS } = require('../utils/rdpPasswordUtil');
const { DEDICATED_OS_VERSIONS } = require('../config/constants');

// Job progres install (in-memory). key: jobId.
const jobs = new Map();
// Index job aktif per user (untuk resume saat halaman di-refresh). key: userId -> jobId.
const jobsByUser = new Map();

function genAlphaNum(n = 18) {
  const raw = crypto.randomBytes(48).toString('base64').replace(/[\/+=]/g, '');
  const body = raw.slice(0, Math.max(12, Number(n) || 18));
  return `${body}-KCSERVER-143`;
}

function genWindowsPassword() {
  for (let i = 0; i < 50; i++) {
    const p = genAlphaNum(14);
    if (/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{10,}$/.test(p)) return p;
  }
  return `Win${Date.now()}A1`;
}

function rootCloudInit(password) {
  return `#cloud-config
ssh_pwauth: true
disable_root: false
chpasswd:
  list: |
    root:${password}
  expire: false
write_files:
  - path: /etc/ssh/sshd_config.d/99-root-password.conf
    permissions: '0644'
    content: |
      PermitRootLogin yes
      PasswordAuthentication yes
      KbdInteractiveAuthentication yes
runcmd:
  - [ sh, -lc, "set -e; (grep -q '^PermitRootLogin' /etc/ssh/sshd_config && sed -i 's/^PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config || echo 'PermitRootLogin yes' >> /etc/ssh/sshd_config); (grep -q '^PasswordAuthentication' /etc/ssh/sshd_config && sed -i 's/^PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config || echo 'PasswordAuthentication yes' >> /etc/ssh/sshd_config); (grep -q '^KbdInteractiveAuthentication' /etc/ssh/sshd_config && sed -i 's/^KbdInteractiveAuthentication.*/KbdInteractiveAuthentication yes/' /etc/ssh/sshd_config || echo 'KbdInteractiveAuthentication yes' >> /etc/ssh/sshd_config); systemctl restart ssh || systemctl restart sshd || service ssh restart || true" ]
`;
}

function normalizeAwsRdpSize(sizeSlug) {
  const size = String(sizeSlug || '');
  const map = {
    't3.micro': 't2.micro', 't3.small': 't2.small', 't3.medium': 't2.medium',
    't3.large': 't2.large', 't3.xlarge': 't2.xlarge',
    'm5.large': 't2.large', 'm5.xlarge': 't2.xlarge'
  };
  return map[size] || size;
}

function getWindowsList() {
  return (DEDICATED_OS_VERSIONS || []).filter(os =>
    os && typeof os.version === 'string' &&
    !os.version.includes('lite') &&
    !os.version.includes('uefi') &&
    os.version !== 'win_10atlas' &&
    os.version !== 'win_2025'
  );
}

async function waitForPort(host, port, totalMs = 12 * 60 * 1000, intervalMs = 15000) {
  const start = Date.now();
  const tryOnce = () => new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; try { socket.destroy(); } catch (_) {} resolve(ok); };
    socket.setTimeout(5000);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
  while (Date.now() - start < totalMs) {
    if (await tryOnce()) return true;
    await new Promise(r => setTimeout(r, intervalMs));
  }
  return false;
}

function setJob(jobId, patch) {
  const cur = jobs.get(jobId) || {};
  jobs.set(jobId, { ...cur, ...patch, updatedAt: Date.now() });
}

function getJob(jobId) {
  return jobs.get(jobId) || null;
}

// Job aktif terakhir milik user (untuk menyambung ulang progres setelah refresh).
function getActiveJobForUser(userId) {
  const jobId = jobsByUser.get(Number(userId));
  if (!jobId) return null;
  const job = jobs.get(jobId);
  if (!job) return null;
  return { jobId, ...job };
}

// Mulai install RDP untuk seorang renter (userId) memakai API miliknya (apiId).
// Return { jobId } segera; proses berjalan async di background.
async function startRdpInstall({ userId, apiId, sizeSlug, region, winIndex }) {
  const token = await renterManager.getApiToken(userId, apiId);
  if (!token) throw new Error('API tidak aktif / tidak ditemukan.');
  const osList = getWindowsList();
  const selectedOS = osList[Number(winIndex)];
  if (!selectedOS) throw new Error('OS Windows tidak valid.');

  const jobId = crypto.randomBytes(8).toString('hex');
  setJob(jobId, { userId, status: 'creating', step: 'Membuat VPS...', ip: null, error: null, provider: providerName(token) });
  jobsByUser.set(Number(userId), jobId);

  (async () => {
    try {
      const rootPass = genAlphaNum(12);
      const rdpPass = genWindowsPassword();
      const hostname = `web-rdp-${userId}-${genAlphaNum(6).toLowerCase()}`;
      const cloudInit = rootCloudInit(rootPass);
      const baseImage = isAwsToken(token) ? 'aws:ubuntu22.04'
        : (isLinodeToken(token) ? 'linode/ubuntu22.04'
        : (isUpCloudToken(token) ? 'upcloud/ubuntu22.04' : 'ubuntu-22-04-x64'));
      const createSizeSlug = isAwsToken(token) ? normalizeAwsRdpSize(sizeSlug) : sizeSlug;

      const createRes = await createDroplet(token, hostname, region, createSizeSlug, baseImage, cloudInit);
      const { dropletId, error } = createRes;
      if (!dropletId) { setJob(jobId, { status: 'failed', error: error || 'Gagal membuat VPS.' }); return; }

      setJob(jobId, { status: 'waiting_ip', step: 'Menunggu VPS aktif & IP...', dropletId });
      const ip = await waitPublicIp(token, dropletId, 20, 10000, region);
      if (!ip) {
        await deleteDroplet(token, dropletId, region);
        setJob(jobId, { status: 'failed', error: 'VPS tidak mendapat IP. Coba lagi.' });
        return;
      }

      const rdpPort = rdpPortForToken(token);
      await renterManager.saveInstance({
        userId, type: 'rdp', dropletId, ip, sizeSlug: createSizeSlug, region,
        image: `rdp:${selectedOS.version}`, rootPassword: rootPass, rdpPassword: rdpPass,
        windowsVersion: selectedOS.version, apiId, rdpPort
      });
      setJob(jobId, { status: 'installing', step: 'Menginstall Windows (30-40 menit)...', ip, rdpPort, rdpPassword: rdpPass, windows: selectedOS.name });

      const sshReady = await waitForPort(ip, 22, 12 * 60 * 1000, 15000);
      if (!sshReady) { setJob(jobId, { status: 'failed', error: 'SSH tidak siap. Silahkan rebuild dari menu VPS/RDP.' }); return; }

      const installProvider = isAwsToken(token) ? 'aws' : (isLinodeToken(token) ? 'linode' : (isUpCloudToken(token) ? 'upcloud' : 'digitalocean'));
      const installCfg = {
        osVersion: selectedOS.version,
        password: rdpPass,
        provider: installProvider,
        rdpPort
      };
      const installPromise = installDedicatedRDP(ip, 'root', rootPass, installCfg, (log) => console.log(`[WEB ${ip}] ${log}`));

      // Fix Linode: Direct Disk adaptif (sama seperti bot).
      if (isLinodeToken(token)) {
        linodeAutoDirectDisk(token, dropletId, { log: (m) => console.log(`[WEB ${ip}] [DirectDisk] ${m}`) })
          .then(res => { if (!res.ok) console.warn(`[WEB ${ip}] Direct Disk TIDAK terverifikasi:`, res.error); })
          .catch(e => console.warn(`[WEB ${ip}] linodeAutoDirectDisk error:`, e.message || e));
      }

      await installPromise;

      // Verifikasi port RDP siap sebelum tandai selesai (sama seperti bot).
      const monitor = new RDPMonitor(ip, 'root', rootPass, rdpPass, rdpPort);
      let rdpResult = { success: false, rdpReady: false };
      try {
        rdpResult = await monitor.waitForRDPReady(RDP_MONITOR_TIMEOUT_MS, (s) => console.log(`[WEB ${ip}] ${s}`));
      } catch (e) {
        console.warn(`[WEB ${ip}] monitor error:`, e.message || e);
      } finally {
        try { monitor.disconnect(); } catch (_) {}
      }

      const address = rdpPort && rdpPort !== 3389 ? `${ip}:${rdpPort}` : ip;
      const verified = !!(rdpResult && rdpResult.success && rdpResult.rdpReady);
      setJob(jobId, {
        status: 'done',
        step: verified ? 'RDP siap!' : 'RDP dibuat (verifikasi port melebihi waktu, coba beberapa menit lagi).',
        ip, rdpPort, rdpPassword: rdpPass
      });

      // Notifikasi ke Telegram renter (best-effort).
      const card =
        `${verified ? '✅ *RDP KAMU SUDAH SIAP!*' : '⚠️ *RDP DIBUAT — verifikasi port melebihi waktu*'}\n\n` +
        `🖥️ *IP / Address:* \`${address}\`\n` +
        `👤 *Username:* \`Administrator\`\n` +
        `🔑 *Password:* \`${rdpPass}\`\n` +
        `🪟 *OS:* ${selectedOS.name}`;
      webNotify.notifyBuyer(userId, card).catch(() => {});
    } catch (e) {
      setJob(jobId, { status: 'failed', error: e.message || 'Install gagal.' });
    }
  })();

  return { jobId };
}

module.exports = { startRdpInstall, getJob, getActiveJobForUser, getWindowsList };
