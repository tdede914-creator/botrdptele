// ============================================================================
// webServer.js — Website untuk renter & admin (TANPA produk digital).
// Fitur: login via Telegram, kelola API cloud sendiri, lihat VPS/RDP milik
// sendiri, install RDP baru, TURN ON/OFF + cek status akun cloud.
//
// Berbagi rdp.db yang sama dengan bot (lewat renterManager & database.js),
// jadi status renter/instance selalu sinkron dengan bot Telegram.
//
// Jalankan: `npm run web`  (port dari WEB_PORT, default 3100).
// ============================================================================

require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');

const renterManager = require('../utils/renterManager');
const vpsManager = require('../utils/vpsManager');
const userManager = require('../utils/userManager');
const {
  powerDroplet, getAccountInfo, getRegions, getSizesForRegion,
  isLinodeToken, isAwsToken, isUpCloudToken, providerName
} = require('../utils/doApi');
const auth = require('./webAuth');
const installer = require('./webInstaller');
const store = require('./webStore');
const wallet = require('./webWallet');

const app = express();
const PORT = Number(process.env.WEB_PORT || 3100);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// ---- Helpers ----------------------------------------------------------------
function ok(res, data = {}) { return res.json({ ok: true, ...data }); }
function fail(res, message, code = 400) { return res.status(code).json({ ok: false, message }); }

async function checkCloudStatus(token) {
  try {
    const info = await getAccountInfo(token);
    if (info && info.ok) return { ok: true, label: 'Aktif', email: info.account?.email || '-' };
    const c = info?.statusCode;
    const reason = (c === 401 || c === 403) ? 'token invalid/dicabut' : (info?.error || 'tidak bisa diverifikasi');
    return { ok: false, label: 'Bermasalah', reason };
  } catch (e) {
    return { ok: false, label: 'Bermasalah', reason: e.message || 'error' };
  }
}

// ---- Auth routes ------------------------------------------------------------
app.post('/api/auth/request-code', async (req, res) => {
  try {
    const r = await auth.requestLoginCode(req.body.identifier);
    if (!r.ok) return fail(res, r.message);
    return ok(res, { userId: r.userId, message: r.message });
  } catch (e) { return fail(res, e.message || 'Error', 500); }
});

app.post('/api/auth/verify-code', async (req, res) => {
  try {
    const r = await auth.verifyLoginCode(req.body.userId, req.body.code);
    if (!r.ok) return fail(res, r.message);
    res.cookie('sid', r.token, { httpOnly: true, sameSite: 'lax', maxAge: 24 * 60 * 60 * 1000 });
    return ok(res, { isAdmin: r.isAdmin });
  } catch (e) { return fail(res, e.message || 'Error', 500); }
});

app.post('/api/auth/logout', auth.requireAuth, (req, res) => {
  auth.destroySession(req.cookies.sid);
  res.clearCookie('sid');
  return ok(res);
});

app.get('/api/me', auth.requireAuth, async (req, res) => {
  const renter = await renterManager.getRenter(req.user.userId);
  let balance = 0;
  try { balance = await userManager.getBalance(req.user.userId); } catch (_) {}
  return ok(res, {
    userId: req.user.userId,
    isAdmin: req.user.isAdmin,
    isRenter: !!req.user.isRenter,
    role: req.user.role || (req.user.isAdmin ? 'admin' : (req.user.isRenter ? 'renter' : 'user')),
    username: renter?.username || null,
    expiresAt: renter?.expires_at || null,
    tier: renter?.tier || 'basic',
    balance
  });
});

// ---- API cloud (milik user sendiri) ----------------------------------------
app.get('/api/apis', auth.requireAuth, async (req, res) => {
  const apis = await renterManager.listApis(req.user.userId);
  return ok(res, { apis });
});

app.post('/api/apis', auth.requireAuth, async (req, res) => {
  try {
    const { token, provider } = req.body;
    if (!token) return fail(res, 'Token wajib diisi.');
    await renterManager.addApi(req.user.userId, token, provider || 'digitalocean');
    return ok(res);
  } catch (e) { return fail(res, e.message || 'Gagal menambah API'); }
});

app.delete('/api/apis/:id', auth.requireAuth, async (req, res) => {
  try {
    await renterManager.deleteApi(req.user.userId, Number(req.params.id));
    return ok(res);
  } catch (e) { return fail(res, e.message || 'Gagal menghapus API'); }
});

// Cek status akun cloud untuk 1 API milik user.
app.get('/api/apis/:id/status', auth.requireAuth, async (req, res) => {
  const token = await renterManager.getApiToken(req.user.userId, Number(req.params.id));
  if (!token) return fail(res, 'API tidak ditemukan.', 404);
  const st = await checkCloudStatus(token);
  return ok(res, { status: st });
});

// ---- Instances (VPS/RDP milik user sendiri) --------------------------------
app.get('/api/instances', auth.requireAuth, async (req, res) => {
  let rows = await renterManager.listInstances(req.user.userId);
  if (req.query.apiId) {
    const apiId = String(req.query.apiId);
    rows = rows.filter(x => String(x.api_id != null ? x.api_id : 'none') === apiId);
  }
  const instances = rows.map(x => ({
    id: x.id, type: x.type, ip: x.ip, droplet_id: x.droplet_id,
    api_id: x.api_id, size_slug: x.size_slug, region: x.region,
    rdp_port: x.rdp_port || 4443, windows_version: x.windows_version
  }));
  return ok(res, { instances });
});

// TURN ON / OFF — scoped ke user & API miliknya.
app.post('/api/instances/:id/power', auth.requireAuth, async (req, res) => {
  try {
    const action = req.body.action === 'on' ? 'on' : 'off';
    const x = await renterManager.getInstance(req.user.userId, Number(req.params.id));
    if (!x || !x.droplet_id) return fail(res, 'Data VPS/RDP tidak ditemukan.', 404);
    const token = x.api_id
      ? await renterManager.getApiToken(req.user.userId, x.api_id)
      : await renterManager.getDefaultApiToken(req.user.userId);
    if (!token) return fail(res, 'API asal VPS/RDP tidak ditemukan.');
    const result = await powerDroplet(token, x.droplet_id, action, x.region);
    if (!result.ok) return fail(res, result.error || 'Gagal power action');
    return ok(res, { action });
  } catch (e) { return fail(res, e.message || 'Error', 500); }
});

// ---- Install RDP baru -------------------------------------------------------
app.get('/api/windows', auth.requireAuth, (req, res) => {
  const list = installer.getWindowsList().map((os, i) => ({ index: i, name: os.name, version: os.version }));
  return ok(res, { windows: list });
});

app.get('/api/regions', auth.requireAuth, async (req, res) => {
  try {
    const token = await renterManager.getApiToken(req.user.userId, Number(req.query.apiId));
    if (!token) return fail(res, 'API tidak ditemukan.', 404);
    const regions = await getRegions(token);
    return ok(res, { regions });
  } catch (e) { return fail(res, e.message || 'Gagal ambil region'); }
});

app.get('/api/sizes', auth.requireAuth, async (req, res) => {
  try {
    const token = await renterManager.getApiToken(req.user.userId, Number(req.query.apiId));
    if (!token) return fail(res, 'API tidak ditemukan.', 404);
    const sizes = await getSizesForRegion(token, req.query.region);
    return ok(res, { sizes });
  } catch (e) { return fail(res, e.message || 'Gagal ambil size'); }
});

app.post('/api/install-rdp', auth.requireAuth, async (req, res) => {
  try {
    const { apiId, sizeSlug, region, winIndex } = req.body;
    if (!apiId || !sizeSlug || !region || winIndex == null) return fail(res, 'Data tidak lengkap.');
    const { jobId } = await installer.startRdpInstall({
      userId: req.user.userId, apiId: Number(apiId), sizeSlug, region, winIndex: Number(winIndex)
    });
    return ok(res, { jobId });
  } catch (e) { return fail(res, e.message || 'Gagal memulai install'); }
});

// PENTING: rute statis '/active' HARUS didaftarkan SEBELUM '/:jobId',
// kalau tidak Express menganggap "active" sebagai nilai :jobId.
app.get('/api/install-rdp/active', auth.requireAuth, (req, res) => {
  const job = installer.getActiveJobForUser(req.user.userId);
  if (!job) return ok(res, { active: false });
  return ok(res, {
    active: true, jobId: job.jobId,
    status: job.status, step: job.step, ip: job.ip, error: job.error,
    rdpPort: job.rdpPort, rdpPassword: job.status === 'done' ? job.rdpPassword : undefined
  });
});

app.get('/api/install-rdp/:jobId', auth.requireAuth, (req, res) => {
  const job = installer.getJob(req.params.jobId);
  if (!job) return fail(res, 'Job tidak ditemukan.', 404);
  if (Number(job.userId) !== Number(req.user.userId)) return fail(res, 'Bukan job milikmu.', 403);
  return ok(res, {
    status: job.status, step: job.step, ip: job.ip, error: job.error,
    rdpPort: job.rdpPort, rdpPassword: job.status === 'done' ? job.rdpPassword : undefined
  });
});

// ============================================================================
// ETALASE PUBLIK — jual RDP seperti bot (boleh TANPA login).
// Sumber = pool admin (do_api + vps_products), tulis ke vps_instances.
// ============================================================================
app.get('/api/store/products', async (req, res) => {
  try {
    const duration = store.normalizeDuration(req.query.duration || 30);
    const catalog = await store.getCatalog(duration);
    return ok(res, catalog);
  } catch (e) { return fail(res, e.message || 'Gagal ambil katalog'); }
});

app.get('/api/store/os', (req, res) => {
  return ok(res, { os: store.getOsList() });
});

app.get('/api/store/regions', async (req, res) => {
  try {
    const info = await store.resolveRegions({
      ram: req.query.ram, core: req.query.core, duration: req.query.duration
    });
    return ok(res, info);
  } catch (e) {
    const code = e.code === 'OUT_OF_STOCK' ? 409 : 400;
    return fail(res, e.message || 'Gagal ambil region', code);
  }
});

app.post('/api/store/checkout', auth.optionalAuth, async (req, res) => {
  try {
    const b = req.body || {};
    const result = await store.checkout({
      session: req.user || null,
      productId: b.productId != null ? Number(b.productId) : null,
      ram: b.ram, core: b.core, duration: b.duration,
      region: b.region, osIndex: b.osIndex,
      payMethod: b.payMethod, telegram: b.telegram
    });
    return ok(res, result);
  } catch (e) { return fail(res, e.message || 'Checkout gagal'); }
});

app.get('/api/store/order/:id', auth.optionalAuth, async (req, res) => {
  const r = await store.getOrder({
    orderId: Number(req.params.id),
    token: req.query.token,
    session: req.user || null
  });
  if (!r.ok) return fail(res, r.code === 404 ? 'Order tidak ditemukan.' : 'Tidak boleh mengakses order ini.', r.code || 400);
  return ok(res, { order: r.view });
});

// ---- Pesanan & VPS saya (login) --------------------------------------------
app.get('/api/store/my-orders', auth.requireAuth, async (req, res) => {
  const orders = await store.listMyOrders(req.user.userId);
  return ok(res, { orders });
});

app.get('/api/store/my-vps', auth.requireAuth, async (req, res) => {
  const rows = await vpsManager.listUserVps(req.user.userId);
  const vps = rows.map(x => ({
    id: x.id, ip: x.ip, region: x.region, image: x.image,
    productType: x.product_type, sizeSlug: x.size_slug, price: x.price,
    rdpPort: x.rdp_port || 4443, createdAt: x.created_at
  }));
  return ok(res, { vps });
});

app.post('/api/store/vps/:id/power', auth.requireAuth, async (req, res) => {
  try {
    const action = req.body.action === 'on' ? 'on' : 'off';
    const target = await vpsManager.getAdminPowerTarget('normal', Number(req.params.id));
    if (!target) return fail(res, 'VPS/RDP tidak ditemukan.', 404);
    if (!req.user.isAdmin && String(target.user_id) !== String(req.user.userId)) {
      return fail(res, 'Bukan VPS/RDP milikmu.', 403);
    }
    if (!target.token) return fail(res, 'API asal VPS/RDP tidak ditemukan.');
    const result = await powerDroplet(target.token, target.droplet_id, action, target.region);
    if (!result.ok) return fail(res, result.error || 'Gagal power action');
    return ok(res, { action });
  } catch (e) { return fail(res, e.message || 'Error', 500); }
});

// ============================================================================
// DOMPET — saldo + top-up QRIS (login). Saldo sama dengan bot (users.balance).
// ============================================================================
app.get('/api/wallet/balance', auth.requireAuth, async (req, res) => {
  const balance = await userManager.getBalance(req.user.userId);
  return ok(res, { balance });
});

app.post('/api/wallet/topup', auth.requireAuth, async (req, res) => {
  try {
    const result = await wallet.createTopup(req.user.userId, Number(req.body.amount));
    return ok(res, result);
  } catch (e) { return fail(res, e.message || 'Gagal membuat top-up'); }
});

app.get('/api/wallet/my-topups', auth.requireAuth, async (req, res) => {
  const topups = await wallet.listMyTopups(req.user.userId);
  return ok(res, { topups });
});

app.get('/api/wallet/topup/:id', auth.requireAuth, async (req, res) => {
  const view = await wallet.getTopup(req.user.userId, Number(req.params.id), req.user.isAdmin);
  if (!view) return fail(res, 'Top-up tidak ditemukan.', 404);
  return ok(res, { topup: view });
});

// ============================================================================
// ADMIN — Full CRUD produk, kelola pool API, monitor instance & order web.
// ============================================================================
// -- Produk (vps_products, product_type = 'rdp') --
app.get('/api/admin/products', auth.requireAdmin, async (req, res) => {
  const products = await vpsManager.listProductsAdmin('rdp');
  return ok(res, { products });
});

app.post('/api/admin/products', auth.requireAdmin, async (req, res) => {
  try {
    const b = req.body || {};
    if (!b.apiId || !b.sizeSlug) return fail(res, 'apiId & sizeSlug wajib diisi.');
    const product = await vpsManager.addRdpProduct({
      apiId: Number(b.apiId), sizeSlug: b.sizeSlug,
      ram: Number(b.ram) || 0, core: Number(b.core) || 0,
      priceDaily: b.priceDaily != null ? Number(b.priceDaily) : null,
      priceWeekly: b.priceWeekly != null ? Number(b.priceWeekly) : null,
      priceMonthly: b.priceMonthly != null ? Number(b.priceMonthly) : null,
      slotDaily: Number(b.slotDaily) || 0,
      slotWeekly: Number(b.slotWeekly) || 0,
      slotMonthly: Number(b.slotMonthly) || 0
    });
    return ok(res, { product });
  } catch (e) { return fail(res, e.message || 'Gagal menambah produk'); }
});

app.post('/api/admin/products/:id/price', auth.requireAdmin, async (req, res) => {
  try {
    const b = req.body || {};
    await vpsManager.updateProductPriceById(Number(req.params.id), {
      daily: b.daily != null ? Number(b.daily) : null,
      weekly: b.weekly != null ? Number(b.weekly) : null,
      monthly: b.monthly != null ? Number(b.monthly) : null
    });
    return ok(res);
  } catch (e) { return fail(res, e.message || 'Gagal update harga'); }
});

app.post('/api/admin/products/:id/slots', auth.requireAdmin, async (req, res) => {
  try {
    const b = req.body || {};
    await vpsManager.setProductSlots(Number(req.params.id), {
      daily: b.daily != null ? Number(b.daily) : null,
      weekly: b.weekly != null ? Number(b.weekly) : null,
      monthly: b.monthly != null ? Number(b.monthly) : null
    });
    return ok(res);
  } catch (e) { return fail(res, e.message || 'Gagal set slot'); }
});

app.post('/api/admin/products/:id/status', auth.requireAdmin, async (req, res) => {
  try {
    await vpsManager.setProductStatus(Number(req.params.id), req.body.status ? 1 : 0);
    return ok(res);
  } catch (e) { return fail(res, e.message || 'Gagal ubah status'); }
});

app.delete('/api/admin/products/:id', auth.requireAdmin, async (req, res) => {
  try {
    await vpsManager.deleteProduct(Number(req.params.id));
    return ok(res);
  } catch (e) { return fail(res, e.message || 'Gagal hapus produk'); }
});

// -- Pool API cloud admin (do_api) --
app.get('/api/admin/apis', auth.requireAdmin, async (req, res) => {
  const apis = await vpsManager.listDoApis();
  return ok(res, {
    apis: (apis || []).map(a => ({
      id: a.id, email: a.email, status: a.status,
      provider: providerName(a.token), createdAt: a.created_at
    }))
  });
});

app.post('/api/admin/apis', auth.requireAdmin, async (req, res) => {
  try {
    if (!req.body.token) return fail(res, 'Token wajib diisi.');
    const result = await vpsManager.addDoApiToken(req.body.token);
    return ok(res, { result });
  } catch (e) { return fail(res, e.message || 'Gagal menambah API'); }
});

app.get('/api/admin/apis/:id/status', auth.requireAdmin, async (req, res) => {
  const token = await vpsManager.getDoApiTokenAny(Number(req.params.id));
  if (!token) return fail(res, 'API tidak ditemukan.', 404);
  const st = await checkCloudStatus(token);
  return ok(res, { status: st });
});

app.post('/api/admin/apis/:id/disable', auth.requireAdmin, async (req, res) => {
  try { await vpsManager.disableDoApi(Number(req.params.id)); return ok(res); }
  catch (e) { return fail(res, e.message || 'Gagal menonaktifkan API'); }
});

app.delete('/api/admin/apis/:id', auth.requireAdmin, async (req, res) => {
  try { await vpsManager.deleteDoApiPermanent(Number(req.params.id)); return ok(res); }
  catch (e) { return fail(res, e.message || 'Gagal menghapus API'); }
});

// -- Semua instance terjual + power on/off --
app.get('/api/admin/instances', auth.requireAdmin, async (req, res) => {
  const instances = await vpsManager.listAllActiveInstances();
  return ok(res, { instances });
});

app.post('/api/admin/instances/:id/power', auth.requireAdmin, async (req, res) => {
  try {
    const action = req.body.action === 'on' ? 'on' : 'off';
    const source = req.body.source === 'renter' ? 'renter' : 'normal';
    const target = await vpsManager.getAdminPowerTarget(source, Number(req.params.id));
    if (!target || !target.token) return fail(res, 'VPS/RDP atau API tidak ditemukan.', 404);
    const result = await powerDroplet(target.token, target.droplet_id, action, target.region);
    if (!result.ok) return fail(res, result.error || 'Gagal power action');
    return ok(res, { action });
  } catch (e) { return fail(res, e.message || 'Error', 500); }
});

// -- Riwayat order web --
app.get('/api/admin/orders', auth.requireAdmin, async (req, res) => {
  const orders = await store.listAllOrders(Number(req.query.limit) || 200);
  return ok(res, { orders });
});

// SPA fallback -> index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`🌐 Web server jalan di http://localhost:${PORT}`);
  if (!process.env.TELEGRAM_BOT_TOKEN) console.warn('⚠️  TELEGRAM_BOT_TOKEN belum diset — login via Telegram & notifikasi tidak akan bekerja.');
  // Resume order/top-up yang menggantung setelah restart. Ditunda ~4 dtk agar
  // tabel web_orders/web_topups (dibuat async saat require database.js) dijamin
  // sudah ada sebelum di-query.
  setTimeout(() => {
    store.initStore().catch(e => console.error('[web] initStore error:', e.message || e));
    wallet.initWallet().catch(e => console.error('[web] initWallet error:', e.message || e));
  }, 4000);
});

module.exports = app;
