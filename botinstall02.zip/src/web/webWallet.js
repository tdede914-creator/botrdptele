// ============================================================================
// webWallet.js — Top-up SALDO lewat website via QRIS.
//
// Saldo yang sama dengan bot (users.balance). Begitu QRIS lunas, saldo bertambah
// dan bisa dipakai untuk checkout RDP metode "saldo".
//
// Uang harus aman terhadap restart -> state disimpan di tabel web_topups dan
// di-resume saat boot (initWallet). Poller in-memory persis pola webStore.
// ============================================================================

const QRCode = require('qrcode');
const db = require('../config/database');
const userManager = require('../utils/userManager');
const { createPayment, checkPaymentStatus, cancelPayment, isPaymentStatusSuccessful } = require('../utils/payment');

const POLL_INTERVAL_MS = 12000;
const MIN_TOPUP = 1000;

const now = () => Math.floor(Date.now() / 1000);
const pollers = new Map(); // topupId -> intervalId

async function getRow(id) { return await db.get('SELECT * FROM web_topups WHERE id = ?', [id]); }

async function patch(id, p) {
  const data = { ...p, updated_at: now() };
  const cols = Object.keys(data);
  const sets = cols.map(k => `${k} = ?`).join(', ');
  const vals = cols.map(k => data[k]);
  vals.push(id);
  await db.run(`UPDATE web_topups SET ${sets} WHERE id = ?`, vals);
}

function toView(o) {
  if (!o) return null;
  return {
    id: o.id,
    amount: o.amount,
    status: o.status,
    qrImage: o.status === 'awaiting_payment' ? (o.qr_image || null) : null,
    qrString: o.status === 'awaiting_payment' ? (o.qr_string || null) : null,
    expireAt: o.expire_at || null,
    createdAt: o.created_at
  };
}

// Buat top-up QRIS untuk user (wajib login).
async function createTopup(userId, amount) {
  const amt = Math.floor(Number(amount) || 0);
  if (!userId) throw new Error('Harus login.');
  if (userManager.isAdmin(userId)) throw new Error('Admin punya saldo tak terbatas, tidak perlu top-up.');
  if (!Number.isFinite(amt) || amt < MIN_TOPUP) throw new Error(`Minimal top-up Rp ${MIN_TOPUP.toLocaleString('id-ID')}.`);

  const reff = `WEBTOPUP${Date.now()}${userId}`;
  let pay;
  try {
    pay = await createPayment(process.env.DOMPETX_API_KEY, reff, amt);
  } catch (e) {
    throw new Error('Gagal membuat pembayaran QRIS: ' + (e.message || e));
  }
  if (!pay || !pay.success || !pay.data || !pay.data.qr_string) {
    throw new Error((pay && pay.error) || 'QRIS tidak tersedia dari gateway.');
  }

  let qrImage = null;
  try { qrImage = await QRCode.toDataURL(pay.data.qr_string, { width: 360, margin: 2 }); }
  catch (_) { qrImage = pay.data.qr_image || null; }
  const expireAt = pay.data.expired_at ? Math.floor(new Date(pay.data.expired_at).getTime() / 1000) : now() + 30 * 60;

  const res = await db.run(
    `INSERT INTO web_topups (user_id, amount, pay_ref, qr_string, qr_image, status, created_at, updated_at, expire_at)
     VALUES (?,?,?,?,?,?,?,?,?)`,
    [userId, amt, pay.data.id, pay.data.qr_string, qrImage, 'awaiting_payment', now(), now(), expireAt]
  );
  armPoller(res.id);
  const row = await getRow(res.id);
  return { topupId: res.id, view: toView(row) };
}

function armPoller(id) {
  if (pollers.has(id)) return;
  const t = setInterval(() => { pollTick(id).catch(e => console.error('[webWallet] poll error:', e.message || e)); }, POLL_INTERVAL_MS);
  pollers.set(id, t);
}
function clearPoller(id) { const t = pollers.get(id); if (t) { clearInterval(t); pollers.delete(id); } }

async function pollTick(id) {
  const row = await getRow(id);
  if (!row) { clearPoller(id); return; }
  if (row.status !== 'awaiting_payment') { clearPoller(id); return; }
  if (row.expire_at && now() > row.expire_at) {
    clearPoller(id);
    await patch(id, { status: 'expired' });
    try { await cancelPayment(row.pay_ref); } catch (_) {}
    return;
  }
  let st;
  try { st = await checkPaymentStatus(process.env.DOMPETX_API_KEY, row.pay_ref); }
  catch (e) { return; }
  if (st && st.success && isPaymentStatusSuccessful(st.data)) {
    clearPoller(id);
    await creditTopup(id);
  }
}

// Kredit saldo tepat sekali (idempoten via kolom credited).
async function creditTopup(id) {
  const row = await getRow(id);
  if (!row || row.credited) return;
  await patch(id, { credited: 1, status: 'done' });
  try {
    await userManager.addBalance(row.user_id, row.amount);
  } catch (e) {
    console.error('[webWallet] addBalance gagal:', e.message || e);
    // balikkan flag supaya bisa dicoba lagi manual bila perlu
    await patch(id, { credited: 0, status: 'awaiting_payment' });
  }
}

async function getTopup(userId, id, isAdmin = false) {
  const row = await getRow(id);
  if (!row) return null;
  if (!isAdmin && String(row.user_id) !== String(userId)) return null;
  return toView(row);
}

async function listMyTopups(userId) {
  const rows = await db.all('SELECT * FROM web_topups WHERE user_id = ? ORDER BY id DESC LIMIT 30', [userId]);
  return rows.map(toView);
}

// Resume saat boot: pasang ulang poller yang belum expired, kedaluwarsakan sisanya.
async function initWallet() {
  try {
    const awaiting = await db.all("SELECT * FROM web_topups WHERE status = 'awaiting_payment'");
    for (const o of awaiting) {
      if (o.expire_at && now() > o.expire_at) {
        await patch(o.id, { status: 'expired' });
        try { await cancelPayment(o.pay_ref); } catch (_) {}
      } else {
        armPoller(o.id);
      }
    }
    console.log(`[webWallet] init: ${awaiting.length} top-up menunggu QRIS.`);
  } catch (e) {
    console.error('[webWallet] initWallet error:', e.message || e);
  }
}

module.exports = { createTopup, getTopup, listMyTopups, initWallet };
